; ZeroJunk installer - Inno Setup 6.3 or newer. Built by build.bat (run PyInstaller first).
[Setup]
AppId={{6E1B7C52-3D0A-4B7E-9C5F-2A8D4F1E9B30}
AppName=ZeroJunk
AppVersion=1.0
AppPublisher=ZeroJunk
DefaultDirName={autopf}\ZeroJunk
DefaultGroupName=ZeroJunk
DisableProgramGroupPage=yes
OutputDir=..\release
OutputBaseFilename=ZeroJunk_Setup
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
; Per-user install: no admin needed, and the history folder (%LOCALAPPDATA%) matches the user.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
UninstallDisplayName=ZeroJunk
UninstallDisplayIcon={app}\ZeroJunk.exe
WizardStyle=modern

[Files]
Source: "..\dist\ZeroJunk\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autodesktop}\ZeroJunk"; Filename: "{app}\ZeroJunk.exe"
Name: "{autoprograms}\ZeroJunk"; Filename: "{app}\ZeroJunk.exe"
Name: "{autoprograms}\Uninstall ZeroJunk"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\ZeroJunk.exe"; Description: "Start ZeroJunk"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{localappdata}\ZeroJunk"

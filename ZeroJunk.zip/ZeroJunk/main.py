"""main.py - starts ZeroJunk (Windows 10/11 x64).  Run with:  python main.py"""

import sys


def main():
    # Makes the text sharp on high-DPI screens (must run before Tk starts).
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass            # not Windows, or not available: ignore

    try:
        from zerojunk.gui import App
        App().mainloop()
    except Exception:
        # A windowed .exe has no console, so show the error in a box.
        import traceback
        text = traceback.format_exc()
        try:
            import os
            folder = os.path.join(os.environ.get("LOCALAPPDATA", "."), "ZeroJunk")
            os.makedirs(folder, exist_ok=True)
            with open(os.path.join(folder, "zerojunk_error.txt"), "a", encoding="utf-8") as f:
                f.write(text + "\n")
            from tkinter import Tk, messagebox
            root = Tk()
            root.withdraw()
            messagebox.showerror("ZeroJunk could not start", text[-900:])
        except Exception:
            pass
        sys.exit(1)


if __name__ == "__main__":
    main()

"""
gui.py - the Tkinter window.

Layout:   [ sidebar ] [ one of three views ]

    Sidebar views
        MainView        Junk Cleaner  : animated SCAN circle -> result -> Clean
                                        (uses the C backend through bridge.py)
        UninstallerView App Uninstaller: installed apps, deep leftover scan,
                                        "Uninstall & Deep Clean"
                                        (uses uninstaller.py)
        HistoryView     History       : junk cleanings + uninstalls

Anything slow (scan / clean / registry / uninstall) runs in a background thread
(App.run_task) so the window does not freeze.
"""

import math
import os
import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk
from tkinter import font as tkfont

from . import bridge, uninstaller

# ---------- colours and fonts (change them here only) ----------
SIDEBAR = "#e9ecf4"        # frosted light side panel
BG = "#f6f7fb"             # content background
CARD = "#ffffff"
BORDER = "#dde1ea"
TEXT = "#1d1d1f"
MUTED = "#6e6e73"
ACCENT = "#0a7aff"
ACCENT_HOVER = "#0062d6"
TRACK = "#d9e8ff"          # light ring around the SCAN circle
RING_GOOD = "#34c759"      # ring colour when a scan is complete
INACTIVE = "#c4c8d2"
GOOD = "#1f8a3b"
WARN = "#b25e00"
BAD = "#d70015"
DANGER = "#d92d20"
DANGER_HOVER = "#b42318"
SELECT = "#dbe8ff"
FONT = "Segoe UI"


# ---------- small colour helpers ----------
def _rgb(colour):
    colour = colour.lstrip("#")
    return [int(colour[i:i + 2], 16) for i in (0, 2, 4)]


def _hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in rgb)


def mix(a, b, t):
    """Colour between a (t=0) and b (t=1). Tk has no transparency, so soft
    glows are made by mixing a colour with the background."""
    t = max(0.0, min(1.0, t))
    return _hex([x + (y - x) * t for x, y in zip(_rgb(a), _rgb(b))])


def smooth(t):
    t = max(0.0, min(1.0, t))
    return t * t * (3 - 2 * t)


def write_crash_log(text):
    """Saves an error text to %LOCALAPPDATA%\\ZeroJunk\\zerojunk_error.txt."""
    try:
        folder = os.path.join(os.environ.get("LOCALAPPDATA", "."), "ZeroJunk")
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, "zerojunk_error.txt"), "a",
                  encoding="utf-8") as file:
            file.write(text + "\n")
    except OSError:
        pass


def plural_files(count):
    return "%d file%s" % (count, "" if count == 1 else "s")


def round_rect_points(x1, y1, x2, y2, r):
    """Points for a smooth=True polygon that looks like a rounded rectangle."""
    return [x1 + r, y1, x1 + r, y1, x2 - r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
            x2, y1 + r, x2, y2 - r, x2, y2 - r, x2, y2, x2 - r, y2, x2 - r, y2,
            x1 + r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y2 - r,
            x1, y1 + r, x1, y1 + r, x1, y1]


# =====================================================
# Reusable widgets
# =====================================================
class FadeCanvas(tk.Canvas):
    """Canvas that fades between two colours (fill + text) in a few frames:
    this is what gives buttons and sidebar items their smooth hover."""

    def _fade_init(self, fill, text):
        self._cur = _rgb(fill) + _rgb(text)
        self._tgt = list(self._cur)
        self._fade_job = None

    def fade_to(self, fill, text, instant=False):
        self._tgt = _rgb(fill) + _rgb(text)
        if instant:
            self._cur = list(self._tgt)
            self._paint_cur()
        elif self._fade_job is None:
            self._fade_step()

    def _fade_step(self):
        try:
            done = True
            for i in range(6):
                delta = self._tgt[i] - self._cur[i]
                if abs(delta) > 1:
                    self._cur[i] += delta * 0.4
                    done = False
                else:
                    self._cur[i] = self._tgt[i]
            self._paint_cur()
            self._fade_job = None if done else self.after(16, self._fade_step)
        except tk.TclError:                    # widget was destroyed
            self._fade_job = None

    def _paint_cur(self):
        self.paint(_hex(self._cur[:3]), _hex(self._cur[3:]))

    def paint(self, fill, text):               # overridden
        pass


class PillButton(FadeCanvas):
    """Rounded button. kind: 'primary' (blue), 'danger' (red), 'ghost' (soft)."""

    STYLES = {   # normal fill, hover fill, text, disabled fill, disabled text
        "primary": (ACCENT, ACCENT_HOVER, "#ffffff", INACTIVE, "#ffffff"),
        "danger": (DANGER, DANGER_HOVER, "#ffffff", INACTIVE, "#ffffff"),
        "ghost": ("#e8f0ff", "#d4e4ff", ACCENT, "#eef0f4", "#a8adb8"),
    }

    def __init__(self, parent, text, command, scale, kind="primary", bg=BG,
                 height=40, padx=30, font_size=11):
        self._font = tkfont.Font(family=FONT, size=font_size, weight="bold")
        self._padx = int(padx * scale)
        self._h = int(height * scale)
        self._command = command
        self._style = self.STYLES[kind]
        self._enabled = True
        super().__init__(parent, width=1, height=self._h, bg=bg,
                         highlightthickness=0, cursor="hand2")
        self.shape = self.create_polygon([0, 0, 0, 0], smooth=True)
        self.label = self.create_text(0, 0, text=text, font=self._font)
        self._layout(text)
        self._fade_init(self._style[0], self._style[2])
        self._paint_cur()
        self.bind("<Enter>", lambda e: self._hover(True))
        self.bind("<Leave>", lambda e: self._hover(False))
        self.bind("<ButtonRelease-1>", self._release)

    def _layout(self, text):
        width = self._font.measure(text) + 2 * self._padx
        self.config(width=width)
        self.coords(self.shape, *round_rect_points(1, 1, width - 1, self._h - 1,
                                                   (self._h - 2) // 2))
        self.coords(self.label, width // 2, self._h // 2)
        self.itemconfig(self.label, text=text)

    def paint(self, fill, text):
        self.itemconfig(self.shape, fill=fill, outline=fill)
        self.itemconfig(self.label, fill=text)

    def _hover(self, inside):
        if self._enabled:
            self.fade_to(self._style[1] if inside else self._style[0], self._style[2])

    def _release(self, event):
        if self._enabled and 0 <= event.x <= self.winfo_width() \
                and 0 <= event.y <= self._h:
            self._command()

    def set_text(self, text):
        self._layout(text)

    def set_enabled(self, enabled):
        self._enabled = enabled
        self.config(cursor="hand2" if enabled else "arrow")
        if enabled:
            self.fade_to(self._style[0], self._style[2])
        else:
            self.fade_to(self._style[3], self._style[4])


class NavItem(FadeCanvas):
    """One sidebar entry: icon + text, soft hover, blue when active."""

    def __init__(self, parent, text, icon, command, scale, width):
        self.scale = scale
        self._h = int(42 * scale)
        self.active = False
        self._command = command
        super().__init__(parent, width=width, height=self._h, bg=SIDEBAR,
                         highlightthickness=0, cursor="hand2")
        self.shape = self.create_polygon(
            round_rect_points(1, 1, width - 1, self._h - 1, int(11 * scale)),
            smooth=True, fill=SIDEBAR, outline=SIDEBAR)
        self._draw_icon(icon, int(24 * scale), self._h // 2)
        self.label = self.create_text(int(46 * scale), self._h // 2, text=text,
                                      anchor="w", font=(FONT, 11), fill=TEXT)
        self._fade_init(SIDEBAR, TEXT)
        self.bind("<Enter>", lambda e: self._colors(hover=True))
        self.bind("<Leave>", lambda e: self._colors(hover=False))
        self.bind("<Button-1>", lambda e: self._command())

    def _draw_icon(self, icon, cx, cy):
        s = 8 * self.scale
        w = max(2, int(1.8 * self.scale))
        if icon == "clean":                                   # sparkle
            k = 0.3
            self.create_polygon(
                cx, cy - s, cx + s * k, cy - s * k, cx + s, cy, cx + s * k, cy + s * k,
                cx, cy + s, cx - s * k, cy + s * k, cx - s, cy, cx - s * k, cy - s * k,
                tags="ic_solid")
        elif icon == "apps":                                  # box + arrow down
            self.create_rectangle(cx - s, cy - s * 0.85, cx + s, cy + s * 0.85,
                                  width=w, tags="ic_out")
            self.create_line(cx, cy - s * 0.45, cx, cy + s * 0.35, width=w,
                             tags="ic_line")
            self.create_line(cx - s * 0.45, cy, cx, cy + s * 0.45, cx + s * 0.45, cy,
                             width=w, tags="ic_line")
        else:                                                 # clock
            self.create_oval(cx - s, cy - s, cx + s, cy + s, width=w, tags="ic_out")
            self.create_line(cx, cy, cx, cy - s * 0.55, width=w, tags="ic_line")
            self.create_line(cx, cy, cx + s * 0.45, cy + s * 0.25, width=w,
                             tags="ic_line")

    def paint(self, fill, text):
        self.itemconfig(self.shape, fill=fill, outline=fill)
        self.itemconfig(self.label, fill=text)
        self.itemconfig("ic_solid", fill=text, outline=text)
        self.itemconfig("ic_out", outline=text)
        self.itemconfig("ic_line", fill=text)

    def _colors(self, hover=False):
        if self.active:
            self.fade_to(ACCENT, "#ffffff")
        elif hover:
            self.fade_to("#dbe0ee", TEXT)
        else:
            self.fade_to(SIDEBAR, TEXT)

    def set_active(self, active):
        self.active = active
        self._colors()


class Card(tk.Canvas):
    """A white rounded card with a thin border. Put content in card.body."""

    def __init__(self, parent, scale, height=60, fill=CARD, outer=BG):
        super().__init__(parent, width=1, height=int(height * scale), bg=outer,
                         highlightthickness=0)
        self.radius = int(14 * scale)
        self.inset = int(8 * scale)
        self.fill = fill
        self.body = tk.Frame(self, bg=fill)
        self._window = self.create_window(self.inset, self.inset, window=self.body,
                                          anchor="nw")
        self.bind("<Configure>", self._redraw)

    def _redraw(self, event):
        w, h = event.width, event.height
        self.delete("card")
        self.create_polygon(round_rect_points(1, 1, w - 1, h - 1, self.radius),
                            smooth=True, fill=self.fill, outline=BORDER, tags="card")
        self.tag_lower("card")
        self.itemconfigure(self._window, width=max(1, w - 2 * self.inset),
                           height=max(1, h - 2 * self.inset))


# =====================================================
# Main view: animated SCAN circle -> result -> Clean
# =====================================================
class MainView(tk.Frame):
    GLOW_LAYERS = 5
    DISC_LAYERS = 16
    SPIN_SPEED = 430.0              # degrees per second of the scanning arc
    FRAME_MS = 16                   # target frame time while animating
    ARC_FRACS = (1.0, 0.62, 0.30)   # tapered tail: long faint -> short bright
    ARC_GAIN = (0.22, 0.55, 1.0)
    ARC_WIDTH = 3                   # thickness of the spinning arc (3 = sleek; 8-10 = bold like the reference)

    def __init__(self, parent, app):
        super().__init__(parent, bg=BG)
        self.app = app
        self.scan = None                # result of the latest scan, or None
        self.state = "idle"             # idle / scanning / ready / cleaning / cleaned
        self.busy = False               # True while scanning or cleaning

        # animation values (all eased in _frame)
        self.spin_t = 0.0               # 0..1  how "busy" the ring looks
        self.done_t = 0.0               # 0..1  completed (green full ring)
        self.hover_t = 0.0
        self._hover = False
        self.progress = 0.0
        self.ang = 90.0                 # start angle of the spinning arc (90 = 12 o'clock)
        self._busy_start = 0.0
        self._expected = {"scanning": 4.0, "cleaning": 6.0}   # learned durations
        self._t0 = self._last = time.perf_counter()
        self._frame_job = None
        self._layer_key = None
        self._cur_text = ("SCAN", "", 28)
        self._pending_text = None
        self._text_alpha = 1.0

        # --- top bar ---
        tk.Label(self, text="Junk Cleaner", font=(FONT, 20, "bold"),
                 bg=BG, fg=TEXT).pack(anchor="w")
        tk.Label(self, text="Temp file cleaner. Nothing is deleted without your confirmation.",
                 font=(FONT, 9), bg=BG, fg=MUTED).pack(anchor="w")

        # --- footer (packed before the centre so it keeps its place) ---
        self.last_label = tk.Label(self, text="", font=(FONT, 9), bg=BG, fg=MUTED)
        self.last_label.pack(side="bottom", pady=(8, 0))

        # --- centre: circle, status, Clean button ---
        centre = tk.Frame(self, bg=BG)
        centre.pack(expand=True)
        self._build_circle(centre)

        self.status = tk.Label(centre, text="", font=(FONT, 11), bg=BG, fg=MUTED,
                               justify="center", wraplength=int(460 * app.scale))
        self.status.pack(pady=(10, 14))

        self.clean_button = PillButton(centre, "Clean", self.start_clean, app.scale,
                                       padx=44)
        self.clean_button.pack()

        self.reset_view()

    # ---------- the circle ----------
    def _build_circle(self, parent):
        s = self.app.scale
        self.R = int(92 * s)                       # disc radius
        self.RR = self.R + int(16 * s)             # ring radius
        size = 2 * (self.R + int(46 * s))
        self.C = size / 2
        c, R, RR = self.C, self.R, self.RR
        self.s = s

        self.canvas = tk.Canvas(parent, width=size, height=size, bg=BG,
                                highlightthickness=0)
        self.canvas.pack()
        cv = self.canvas

        # soft glow (largest first, so smaller ones sit on top)
        self.glow = [None] * self.GLOW_LAYERS
        for k in reversed(range(self.GLOW_LAYERS)):
            self.glow[k] = cv.create_oval(0, 0, 0, 0, fill=BG, outline="")
        ring_w = max(2, int(3 * s))
        self.track = cv.create_oval(c - RR, c - RR, c + RR, c + RR,
                                    outline=TRACK, width=ring_w)
        # disc made of stacked circles = soft vertical gradient
        self.layers = []
        n = self.DISC_LAYERS
        for i in range(n):
            f = i / (n - 1)
            r = R * (1 - 0.47 * f)
            cy = c - R * 0.20 * f
            self.layers.append(cv.create_oval(c - r, cy - r, c + r, cy + r,
                                              fill=ACCENT, outline=""))

        # one sleek, thin sweeping arc. Three stacked arcs of the SAME thin width
        # share the leading edge, so the tail fades out instead of getting thicker.
        self.arc = [cv.create_arc(c - RR, c - RR, c + RR, c + RR, start=90,
                                  extent=30, style="arc", outline=BG,
                                  width=max(2, int(round(self.ARC_WIDTH * s))), state="hidden")
                    for _ in self.ARC_FRACS]

        self.t_main = cv.create_text(c, c, text="SCAN", fill="#ffffff",
                                     font=(FONT, 28, "bold"))
        self.t_sub = cv.create_text(c, c + 22 * s, text="", fill="#ffffff",
                                    font=(FONT, 11))

        cv.bind("<Motion>", self._motion)
        cv.bind("<Leave>", lambda e: self._set_hover(False))
        cv.bind("<Button-1>", self._click)

    def _inside(self, event):
        return (event.x - self.C) ** 2 + (event.y - self.C) ** 2 <= (self.R + 4 * self.s) ** 2

    def _set_hover(self, inside):
        self._hover = inside and not self.busy
        self.canvas.config(cursor="hand2" if self._hover else "arrow")

    def _motion(self, event):
        self._set_hover(self._inside(event))

    def _click(self, event):
        if self._inside(event):
            self.start_scan()

    # ---------- text inside the circle (cross-fade) ----------
    def _request_text(self, main, sub="", size=28):
        new = (main, sub, size)
        if new != self._cur_text and new != self._pending_text:
            self._pending_text = new

    def _apply_text(self, text):
        main, sub, size = text
        self._cur_text = text
        c, s = self.C, self.s
        self.canvas.itemconfig(self.t_main, text=main, font=(FONT, size, "bold"))
        self.canvas.itemconfig(self.t_sub, text=sub)
        self.canvas.coords(self.t_main, c, c - (11 * s if sub else 0))
        self.canvas.coords(self.t_sub, c, c + 22 * s)

    # ---------- the 60 fps loop ----------
    def _schedule(self):
        if self._frame_job is None:
            self._last = time.perf_counter()
            self._frame_job = self.after(16, self._frame)

    def _stop_frames(self):
        if self._frame_job is not None:
            self.after_cancel(self._frame_job)
            self._frame_job = None

    def _frame(self):
        self._frame_job = None
        now = time.perf_counter()
        dt = min(now - self._last, 0.05)
        self._last = now
        t = now - self._t0
        cv, c, R, RR, s = self.canvas, self.C, self.R, self.RR, self.s
        busy = self.state in ("scanning", "cleaning")

        def ease(value, target, rate):
            value += (target - value) * min(1.0, dt * rate)
            return target if abs(value - target) < 0.003 else value

        # quick, smooth spin-up; slower, gentle spin-down
        self.spin_t = ease(self.spin_t, 1.0 if busy else 0.0, 7 if busy else 3.2)
        self.done_t = ease(self.done_t, 1.0 if self.state in ("ready", "cleaned") else 0.0, 3.5)
        self.hover_t = ease(self.hover_t, 1.0 if self._hover else 0.0, 12)

        # --- estimated progress (the backend only reports at the end) ---
        if busy:
            expected = max(self._expected[self.state], 0.8)
            elapsed = now - self._busy_start
            self.progress = max(self.progress,
                                0.96 * (1 - math.exp(-elapsed / (expected / 2.5))))

        # --- text cross-fade / live percentage ---
        if self._pending_text is not None:
            self._text_alpha -= dt * 6
            if self._text_alpha <= 0:
                self._text_alpha = 0.0
                self._apply_text(self._pending_text)
                self._pending_text = None
        else:
            self._text_alpha = min(1.0, self._text_alpha + dt * 5)
            if busy and self._text_alpha > 0.5:
                percent = "%d%%" % int(self.progress * 100)
                if self._cur_text[0] != percent and self._cur_text[2] == 30:
                    cv.itemconfig(self.t_main, text=percent)
                    self._cur_text = (percent,) + self._cur_text[1:]

        # --- disc gradient (only when the hover value changed) ---
        key = round(self.hover_t, 2)
        if key != self._layer_key:
            self._layer_key = key
            base = mix(ACCENT, "#000000", 0.10 * self.hover_t)
            dark, light = mix(base, "#000000", 0.20), mix(base, "#ffffff", 0.30)
            n = len(self.layers)
            for i, item in enumerate(self.layers):
                cv.itemconfig(item, fill=mix(dark, light, i / (n - 1)))
        disc_mid = mix(mix(ACCENT, "#000000", 0.10 * self.hover_t), "#ffffff", 0.05)
        pulse = 1.0                              # subtle breathing of the centre text
        if self.state == "scanning":
            pulse = 1.0 - 0.30 * self.spin_t * (0.5 + 0.5 * math.sin(t * 2.6))
        cv.itemconfig(self.t_main, fill=mix(disc_mid, "#ffffff", self._text_alpha * pulse))
        cv.itemconfig(self.t_sub, fill=mix(disc_mid, "#ffffff", self._text_alpha * 0.85))

        ring_col = mix(ACCENT, RING_GOOD, self.done_t)

        # --- breathing glow ---
        breath = 0.5 + 0.5 * math.sin(t * 1.8)
        strength = 0.55 + 0.45 * breath + 0.5 * self.spin_t
        for k, item in enumerate(self.glow):
            r = R + (k + 1) * 5.5 * s * (1 + 0.10 * breath)
            alpha = 0.085 * (1 - k / self.GLOW_LAYERS) * strength
            cv.coords(item, c - r, c - r, c + r, c + r)
            cv.itemconfig(item, fill=mix(BG, ring_col, alpha))
        cv.itemconfig(self.track, outline=mix(TRACK, "#d3f2dc", self.done_t))

        # --- spinning arc: thin, fast, continuous (clockwise, leading edge = start) ---
        self.ang = (self.ang - dt * self.SPIN_SPEED * self.spin_t) % 360
        ext = 40 + 230 * smooth(self.spin_t)                     # grows out of the top to ~3/4
        ext += (359.9 - ext) * smooth(self.done_t)               # closes to a full ring
        self._set_arcs(self.arc, self.ang, ext, ring_col,
                       max(self.spin_t, self.done_t))

        active = (busy or self.spin_t > 0 or self._pending_text is not None
                  or abs(self.done_t - (1.0 if self.state in ("ready", "cleaned") else 0.0)) > 0
                  or self.hover_t not in (0.0, 1.0))
        work_ms = (time.perf_counter() - now) * 1000
        delay = max(4, int(self.FRAME_MS - work_ms)) if active else 33
        self._frame_job = self.after(delay, self._frame)

    @staticmethod
    def _set_arcs_item(cv, item, start, extent, colour, visible):
        cv.itemconfig(item, start=start, extent=extent, outline=colour,
                      state="normal" if visible else "hidden")

    def _set_arcs(self, items, start, extent, colour, strength):
        visible = strength > 0.02
        done = smooth(self.done_t)
        for item, frac, gain in zip(items, self.ARC_FRACS, self.ARC_GAIN):
            frac += (1 - frac) * done            # a finished scan is one even ring
            gain += (1 - gain) * done
            self._set_arcs_item(self.canvas, item, start, max(1.0, extent * frac),
                                mix(BG, colour, gain * strength), visible)

    # ---------- state helpers ----------
    def _begin(self, state, status, label):
        self.state = state
        self.busy = True
        self._hover = False
        self.canvas.config(cursor="arrow")
        self.progress = 0.0
        self._busy_start = time.perf_counter()
        if state == "scanning":
            self._request_text("SCAN", "", 28)       # centre stays calm and crisp
        else:
            self._request_text("0%", label, 30)
        self.show_status(status)
        self.refresh_clean_button()
        # Every run starts from the top: no leftover angle, no stale frame timing.
        self.ang = 90.0
        self._stop_frames()
        self._schedule()

    def _end_busy(self):
        self.busy = False
        self._expected[self.state] = max(0.8, time.perf_counter() - self._busy_start)

    def refresh_clean_button(self):
        ready = (not self.busy and self.scan is not None and self.scan["files"] > 0)
        self.clean_button.set_enabled(ready)

    def show_status(self, text, colour=MUTED):
        self.status.config(text=text, fg=colour)

    def reset_view(self):
        self.scan = None
        self.state = "idle"
        self._request_text("SCAN", "", 28)
        self.show_status("Click the circle to look for junk in your Temp folder.")
        self.refresh_clean_button()
        if bridge.find_backend() is None:
            self.show_status(bridge.BACKEND_NAME + " not found.\n"
                             "Build it first (see README.md).", BAD)

    def on_show(self):
        self.last_label.config(text="Last cleaned: " + (bridge.last_cleaned() or "Never"))
        self._schedule()

    def on_hide(self):
        self._stop_frames()

    # ---------- scan ----------
    def start_scan(self):
        if self.busy:
            return
        self.scan = None
        self._begin("scanning", "Scanning...", "Scanning")
        self.app.run_task(bridge.scan, self.scan_done)

    def scan_done(self, ok, value):
        self._end_busy()
        if not ok:
            self.state = "idle"
            self._request_text("SCAN", "", 28)
            self.show_status(str(value), BAD)
            self.refresh_clean_button()
            messagebox.showerror("Scan failed", str(value))
            return

        self.scan = value
        self.state = "ready"
        if value["files"] > 0:
            self._request_text(bridge.format_size(value["bytes"]),
                               plural_files(value["files"]), 22)
        else:
            self._request_text("All clear", "nothing to clean", 20)
        self.refresh_clean_button()
        if value["incomplete"]:
            self.show_status("Scan finished, but some folders could not be read. "
                             "The numbers may be too low.", WARN)
        elif value["files"] == 0:
            self.show_status("Scan complete. Nothing to clean.", GOOD)
        else:
            self.show_status("Scan complete. Click Clean to remove these files.", GOOD)

    # ---------- clean ----------
    def start_clean(self):
        scan = self.scan
        if self.busy or scan is None or scan["files"] == 0:
            return
        question = "Found %s (%s).\n\nDelete them permanently?" % (
            plural_files(scan["files"]), bridge.format_size(scan["bytes"]))
        if scan["incomplete"]:
            question += ("\n\nWarning: some folders could not be read, "
                         "so more files may exist.")
        if not messagebox.askyesno("Confirm cleaning", question, icon="warning"):
            self.show_status("Cancelled. Nothing was deleted.")
            return

        self._begin("cleaning", "Cleaning...", "Cleaning")
        self.app.run_task(bridge.clean, self.clean_done)

    def clean_done(self, ok, value):
        self._end_busy()
        if not ok:
            self.state = "ready" if self.scan else "idle"
            self._request_text(*(("SCAN", "", 28) if not self.scan else
                                 (bridge.format_size(self.scan["bytes"]),
                                  plural_files(self.scan["files"]), 22)))
            self.show_status(str(value), BAD)
            self.refresh_clean_button()
            messagebox.showerror("Cleaning failed", str(value))
            return

        self.scan = None                  # old numbers are out of date: scan again
        self.state = "cleaned"
        self.refresh_clean_button()
        self.on_show()                    # updates "Last cleaned"
        self._request_text(bridge.format_size(value["bytes"]), "freed", 22)

        message, colour = "%s deleted, %d skipped (in use / protected / links)." % (
            plural_files(value["files"]), value["skipped"]), GOOD
        if value["incomplete"]:
            message = ("Cleaned, but some folders could not be read, so some files "
                       "may remain.\n" + message)
            colour = WARN
        if not value["log_saved"]:
            message += "\nThe history log could not be saved."
            colour = WARN
        self.show_status(message + "\nClick the circle to scan again.", colour)


# =====================================================
# App Uninstaller view
# =====================================================
class UninstallerView(tk.Frame):
    PLACEHOLDER = "Search apps"

    def __init__(self, parent, app):
        super().__init__(parent, bg=BG)
        self.app = app
        s = app.scale
        self.apps = []                  # all installed apps
        self.shown = {}                 # tree id -> app
        self.loading = self.loaded = False
        self.busy = False               # uninstalling / cleaning
        self.scanning = False           # deep scan running
        self.selected = None
        self.leftovers = []
        self.checked = set()
        self._token = 0
        self.sort_col, self.sort_rev = "name", False
        self._placeholder = True

        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=3)
        self.rowconfigure(5, weight=2)

        # --- header ---
        head = tk.Frame(self, bg=BG)
        head.grid(row=0, column=0, sticky="ew")
        tk.Label(head, text="App Uninstaller", font=(FONT, 20, "bold"),
                 bg=BG, fg=TEXT).pack(side="left")
        PillButton(head, "Refresh", self.load_apps, s, kind="ghost", height=30,
                   padx=14, font_size=9).pack(side="right")
        tk.Label(self, text="Pick an app: its leftover cache and settings are found "
                            "automatically, then removed after the uninstaller.",
                 font=(FONT, 9), bg=BG, fg=MUTED, anchor="w").grid(
            row=1, column=0, sticky="w")

        # --- search ---
        search = Card(self, s, height=44)
        search.grid(row=2, column=0, sticky="ew", pady=(12, 10))
        icon = tk.Canvas(search.body, width=int(20 * s), height=int(20 * s), bg=CARD,
                         highlightthickness=0)
        icon.create_oval(3 * s, 3 * s, 13 * s, 13 * s, outline=MUTED, width=2)
        icon.create_line(12 * s, 12 * s, 17 * s, 17 * s, fill=MUTED, width=2)
        icon.pack(side="left", padx=(6, 0))
        self.search_var = tk.StringVar(value=self.PLACEHOLDER)
        self.entry = tk.Entry(search.body, textvariable=self.search_var, relief="flat",
                              bd=0, font=(FONT, 11), bg=CARD, fg=MUTED,
                              insertbackground=TEXT)
        self.entry.pack(side="left", fill="x", expand=True, padx=8)
        self.entry.bind("<FocusIn>", self._focus_in)
        self.entry.bind("<FocusOut>", self._focus_out)
        self.search_var.trace_add("write", lambda *a: self._apply_filter())

        # --- installed apps list ---
        list_card = Card(self, s, height=110)
        list_card.grid(row=3, column=0, sticky="nsew")
        columns = ("name", "publisher", "version", "size")
        self.tree = ttk.Treeview(list_card.body, columns=columns, show="headings",
                                 style="ZJ.Treeview", selectmode="browse", height=3)
        for col, title, width, anchor in (("name", "Name", 270, "w"),
                                          ("publisher", "Publisher", 170, "w"),
                                          ("version", "Version", 90, "w"),
                                          ("size", "Est. size", 90, "e")):
            self.tree.heading(col, text=title, command=lambda c=col: self._sort(c))
            self.tree.column(col, width=int(width * s), anchor=anchor,
                             stretch=(col == "name"))
        bar = ttk.Scrollbar(list_card.body, orient="vertical", command=self.tree.yview,
                            style="ZJ.Vertical.TScrollbar")
        self.tree.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # --- selected app: uninstall command ---
        self.info = tk.Label(self, text="", font=(FONT, 9), bg=BG, fg=MUTED,
                             anchor="w", justify="left", wraplength=500)
        self.info.grid(row=4, column=0, sticky="ew", pady=(6, 6))
        self.info.bind("<Configure>", lambda e: self.info.config(wraplength=e.width - 4))

        # --- leftovers ---
        left_card = Card(self, s, height=100)
        left_card.grid(row=5, column=0, sticky="nsew")
        top = tk.Frame(left_card.body, bg=CARD)
        top.pack(fill="x")
        tk.Label(top, text="Leftover files & cache", font=(FONT, 11, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(4, 0))
        PillButton(top, "Select none", lambda: self._set_all(False), s, kind="ghost",
                   bg=CARD, height=26, padx=10, font_size=9).pack(side="right", padx=(6, 2))
        PillButton(top, "Select all", lambda: self._set_all(True), s, kind="ghost",
                   bg=CARD, height=26, padx=10, font_size=9).pack(side="right")
        self.summary = tk.Label(left_card.body, text="", font=(FONT, 9), bg=CARD,
                                fg=MUTED, anchor="w")
        self.summary.pack(fill="x", padx=4)
        holder = tk.Frame(left_card.body, bg=CARD)
        holder.pack(fill="both", expand=True, pady=(4, 0))
        self.left_tree = ttk.Treeview(holder, columns=("loc", "path", "size"),
                                      show="tree headings", style="ZJ.Treeview",
                                      selectmode="none", height=3)
        self.left_tree.heading("#0", text="")
        self.left_tree.column("#0", width=int(36 * s), stretch=False)
        for col, title, width, anchor, stretch in (("loc", "Location", 120, "w", False),
                                                   ("path", "Path", 380, "w", True),
                                                   ("size", "Size", 90, "e", False)):
            self.left_tree.heading(col, text=title)
            self.left_tree.column(col, width=int(width * s), anchor=anchor, stretch=stretch)
        bar2 = ttk.Scrollbar(holder, orient="vertical", command=self.left_tree.yview,
                             style="ZJ.Vertical.TScrollbar")
        self.left_tree.configure(yscrollcommand=bar2.set)
        bar2.pack(side="right", fill="y")
        self.left_tree.pack(side="left", fill="both", expand=True)
        self.left_tree.bind("<Button-1>", self._on_left_click)

        # --- action bar ---
        actions = tk.Frame(self, bg=BG)
        actions.grid(row=6, column=0, sticky="ew", pady=(12, 0))
        self.uninstall_button = PillButton(actions, "Uninstall & Deep Clean",
                                           self.start_uninstall, s, kind="danger", padx=26)
        self.uninstall_button.pack(side="right")
        self.status = tk.Label(actions, text="", font=(FONT, 10), bg=BG, fg=MUTED,
                               anchor="w", justify="left")
        self.status.pack(side="left", fill="x", expand=True, padx=(2, 12))
        self.status.bind("<Configure>", lambda e: self.status.config(wraplength=e.width - 4))

        self.refresh_buttons()
        self._show_leftover_hint()

    # ---------- small helpers ----------
    def set_status(self, text, colour=MUTED):
        self.status.config(text=text, fg=colour)

    def refresh_buttons(self):
        ready = (self.selected is not None and not self.busy and not self.scanning)
        self.uninstall_button.set_enabled(ready)

    def _show_leftover_hint(self):
        self.summary.config(text="Select an app above to scan for its leftover files.")

    def on_show(self):
        if not self.loaded and not self.loading:
            self.load_apps()

    def on_hide(self):
        pass

    # ---------- search / sort / app list ----------
    def _focus_in(self, event):
        if self._placeholder:
            self._placeholder = False
            self.search_var.set("")
            self.entry.config(fg=TEXT)

    def _focus_out(self, event):
        if not self.search_var.get().strip():
            self._placeholder = True
            self.search_var.set(self.PLACEHOLDER)
            self.entry.config(fg=MUTED)

    def _query(self):
        return "" if self._placeholder else self.search_var.get().strip().lower()

    def load_apps(self):
        if self.loading or self.busy:
            return
        self.loading = True
        self.set_status("Reading installed apps...")
        self.app.run_task(uninstaller.list_installed_apps, self._apps_loaded)

    def _apps_loaded(self, ok, value):
        self.loading = False
        if not ok:
            self.set_status("Could not read the installed apps: %s" % value, BAD)
            return
        self.apps = value
        self.loaded = True
        self._apply_filter()

    def _sort(self, column):
        self.sort_rev = (not self.sort_rev) if column == self.sort_col else (column == "size")
        self.sort_col = column
        self._apply_filter()

    def _apply_filter(self):
        query = self._query()
        keys = {"name": lambda a: a["name"].lower(),
                "publisher": lambda a: a["publisher"].lower(),
                "version": lambda a: a["version"],
                "size": lambda a: a["size_bytes"]}
        apps = [a for a in self.apps
                if query in (a["name"] + " " + a["publisher"]).lower()]
        apps.sort(key=keys[self.sort_col], reverse=self.sort_rev)

        titles = {"name": "Name", "publisher": "Publisher", "version": "Version",
                  "size": "Est. size"}
        for col, title in titles.items():
            arrow = (" \u25bc" if self.sort_rev else " \u25b2") if col == self.sort_col else ""
            self.tree.heading(col, text=title + arrow)

        self.tree.delete(*self.tree.get_children())
        self.shown = {}
        for a in apps:
            iid = str(a["id"])
            self.shown[iid] = a
            self.tree.insert("", "end", iid=iid, values=(
                a["name"], a["publisher"] or "-", a["version"] or "-",
                bridge.format_size(a["size_bytes"]) if a["size_bytes"] else "-"))
        if self.selected is not None and str(self.selected["id"]) in self.shown:
            self.tree.selection_set(str(self.selected["id"]))
        if not self.busy and not self.scanning:
            self.set_status("%d of %d apps" % (len(apps), len(self.apps)))

    # ---------- selecting an app -> deep scan ----------
    def _on_select(self, event):
        selection = self.tree.selection()
        if not selection or self.busy:
            return
        app = self.shown.get(selection[0])
        if app is None or app is self.selected:
            return
        self.selected = app
        self._token += 1
        token = self._token
        self.scanning = True
        self.leftovers, self.checked = [], set()
        self._fill_leftovers()
        command = app["uninstall"]
        if len(command) > 170:
            command = command[:170] + "..."
        self.info.config(text="Uninstall command:  " + command)
        self.summary.config(text="Deep scan: looking for leftover files...")
        self.refresh_buttons()
        self.app.run_task(lambda: uninstaller.deep_scan(app),
                          lambda ok, value: self._deep_done(token, ok, value))

    def _deep_done(self, token, ok, value):
        if token != self._token:                 # another app was selected meanwhile
            return
        self.scanning = False
        self.refresh_buttons()
        if not ok:
            self.summary.config(text="Deep scan failed: %s" % value)
            return
        self.leftovers = value["items"]
        self.checked = set(range(len(self.leftovers)))     # all selected by default
        self._fill_leftovers()

    # ---------- leftovers list with checkboxes ----------
    def _fill_leftovers(self):
        self.left_tree.delete(*self.left_tree.get_children())
        for i, item in enumerate(self.leftovers):
            self.left_tree.insert("", "end", iid=str(i),
                                  text="\u2611" if i in self.checked else "\u2610",
                                  values=(item["loc"], item["path"],
                                          bridge.format_size(item["bytes"])))
        self._update_summary()

    def _update_summary(self):
        if self.selected is None:
            self._show_leftover_hint()
            return
        if self.scanning:
            return
        if not self.leftovers:
            self.summary.config(text="No leftover files found for this app.")
            return
        total = sum(i["bytes"] for i in self.leftovers)
        picked = sum(self.leftovers[i]["bytes"] for i in self.checked)
        self.summary.config(text="%d location%s found, %s in total  |  %d selected (%s)" % (
            len(self.leftovers), "" if len(self.leftovers) == 1 else "s",
            bridge.format_size(total), len(self.checked), bridge.format_size(picked)))

    def _on_left_click(self, event):
        if self.busy:
            return "break"
        iid = self.left_tree.identify_row(event.y)
        if iid:
            index = int(iid)
            self.checked.symmetric_difference_update({index})
            self.left_tree.item(iid, text="\u2611" if index in self.checked else "\u2610")
            self._update_summary()
        return "break"

    def _set_all(self, value):
        if self.busy or not self.leftovers:
            return
        self.checked = set(range(len(self.leftovers))) if value else set()
        self._fill_leftovers()

    # ---------- uninstall + deep clean ----------
    def start_uninstall(self):
        app = self.selected
        if self.busy or self.scanning or app is None:
            return
        chosen = [self.leftovers[i] for i in sorted(self.checked)]
        size = bridge.format_size(sum(i["bytes"] for i in chosen))
        question = ("Uninstall \"%s\"?\n\n1. The app's own uninstaller runs first "
                    "(follow its window if one opens).\n" % app["name"])
        if chosen:
            question += ("2. Then %d selected location%s (%s) will be deleted "
                         "permanently." % (len(chosen), "" if len(chosen) == 1 else "s", size))
        else:
            question += "2. No leftover locations are selected, so none will be deleted."
        if not messagebox.askyesno("Confirm uninstall", question, icon="warning"):
            self.set_status("Cancelled. Nothing was changed.")
            return

        self._set_busy(True)
        self.set_status("Running the uninstaller... finish its window if one opens.")
        self.app.run_task(lambda: uninstaller.run_uninstall(app),
                          lambda ok, value: self._uninstall_done(app, chosen, ok, value))

    def _set_busy(self, busy):
        self.busy = busy
        self.tree.config(selectmode="none" if busy else "browse")
        self.refresh_buttons()

    def _uninstall_done(self, app, chosen, ok, value):
        if not ok:
            self._set_busy(False)
            self.set_status(str(value), BAD)
            messagebox.showerror("Uninstall failed", str(value))
            return

        forced = False
        if value["still_installed"]:
            go_on = messagebox.askyesno(
                "Uninstaller did not finish",
                "\"%s\" is still listed as installed (the uninstaller may have been "
                "cancelled or is still open).\n\nIf its window is still open, finish "
                "it first.\n\nDelete the selected leftover files anyway?" % app["name"],
                icon="warning", default="no")
            if not go_on:
                self._set_busy(False)
                self.set_status("Uninstall not completed. No leftover files were deleted.",
                                WARN)
                self._reload()
                return
            forced = uninstaller.is_installed(app)

        if not chosen:
            self._finish(app, {"bytes": 0, "files": 0, "removed": 0, "failed": []}, forced)
            return
        self.set_status("Removing leftover files...")
        self.app.run_task(lambda: uninstaller.delete_items(chosen),
                          lambda ok2, res: self._clean_done(app, forced, ok2, res))

    def _clean_done(self, app, forced, ok, value):
        if not ok:
            self._set_busy(False)
            self.set_status(str(value), BAD)
            messagebox.showerror("Cleaning failed", str(value))
            return
        self._finish(app, value, forced)

    def _finish(self, app, result, forced):
        failed = result["failed"]
        saved = uninstaller.write_log(
            "%s %s (%d leftover location%s removed, %s freed, %d could not be removed)" % (
                "Deep-cleaned (uninstall not confirmed)" if forced else "Uninstalled",
                app["name"], result["removed"], "" if result["removed"] == 1 else "s",
                bridge.format_size(result["bytes"]), len(failed)))
        self._set_busy(False)

        text = "%s: %d leftover location%s removed, %s freed." % (
            app["name"], result["removed"], "" if result["removed"] == 1 else "s",
            bridge.format_size(result["bytes"]))
        colour = GOOD
        if failed:
            colour = WARN
            text += "\n\n%d location%s could not be fully removed (in use or protected):" % (
                len(failed), "" if len(failed) == 1 else "s")
            for path, reason in failed[:6]:
                text += "\n- %s\n   %s" % (path, reason)
            if len(failed) > 6:
                text += "\n... and %d more" % (len(failed) - 6)
            text += "\n\nClose the program that uses them (or restart Windows) and try again."
        if not saved:
            text += "\n\nThe history log could not be saved."
            colour = WARN
        self.set_status(text.split("\n\n")[0], colour)
        messagebox.showinfo("Uninstall finished", text)

        self.selected = None
        self.leftovers, self.checked = [], set()
        self._fill_leftovers()
        self.info.config(text="")
        self._reload()

    def _reload(self):
        self.loaded = False
        self.load_apps()


# =====================================================
# History view
# =====================================================
class HistoryView(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=BG)
        self.app = app

        top = tk.Frame(self, bg=BG)
        top.pack(fill="x")
        tk.Label(top, text="History", font=(FONT, 20, "bold"),
                 bg=BG, fg=TEXT).pack(side="left")
        PillButton(top, "Refresh", self.on_show, app.scale, kind="ghost", height=30,
                   padx=14, font_size=9).pack(side="right")
        tk.Label(self, text="Junk cleanings (saved by the C backend) and app uninstalls, "
                            "newest first.",
                 font=(FONT, 9), bg=BG, fg=MUTED).pack(anchor="w")

        card = Card(self, app.scale, height=200)
        card.pack(fill="both", expand=True, pady=(14, 0))
        scroll = ttk.Scrollbar(card.body, orient="vertical",
                               style="ZJ.Vertical.TScrollbar")
        scroll.pack(side="right", fill="y")
        self.text = tk.Text(card.body, font=("Consolas", 10), bg=CARD, fg=TEXT,
                            relief="flat", bd=0, padx=8, pady=6, state="disabled",
                            yscrollcommand=scroll.set, wrap="word", cursor="arrow",
                            spacing3=4)
        self.text.pack(side="left", fill="both", expand=True)
        scroll.config(command=self.text.yview)
        self.text.tag_config("uninstall", foreground=ACCENT_HOVER)
        self.text.tag_config("empty", foreground=MUTED)

    def on_show(self):
        entries = uninstaller.combined_history()
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        if not entries:
            self.text.insert("1.0", "No history yet.", "empty")
        for line, kind in entries:
            self.text.insert("end", line + "\n", "uninstall" if kind == "uninstall" else ())
        self.text.config(state="disabled")      # read-only

    def on_hide(self):
        pass


# =====================================================
# The window
# =====================================================
class App(tk.Tk):
    NAV = (("main", "Junk Cleaner", "clean"),
           ("uninstaller", "App Uninstaller", "apps"),
           ("history", "History", "history"))

    def __init__(self):
        super().__init__()
        self.title("ZeroJunk")
        self.configure(bg=BG)

        # Size follows the screen scaling (125 %, 150 % ...), so nothing is cut
        # off on high-DPI screens.
        try:
            self.scale = max(1.0, self.winfo_fpixels("1i") / 96.0)
        except tk.TclError:
            self.scale = 1.0
        width, height = int(1000 * self.scale), int(700 * self.scale)
        width = min(width, self.winfo_screenwidth() - 40)
        height = min(height, self.winfo_screenheight() - 80)
        self.geometry("%dx%d+60+30" % (width, height))
        self.minsize(min(int(860 * self.scale), width), min(int(560 * self.scale), height))

        self._setup_styles()

        # --- sidebar ---
        side_w = int(220 * self.scale)
        sidebar = tk.Frame(self, bg=SIDEBAR, width=side_w)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        tk.Frame(self, bg=BORDER, width=1).pack(side="left", fill="y")

        logo = tk.Canvas(sidebar, width=side_w, height=int(70 * self.scale), bg=SIDEBAR,
                         highlightthickness=0)
        logo.pack(pady=(int(8 * self.scale), int(6 * self.scale)))
        s = self.scale
        logo.create_polygon(round_rect_points(18 * s, 18 * s, 50 * s, 50 * s, 10 * s),
                            smooth=True, fill=ACCENT, outline=ACCENT)
        cx, cy, r, k = 34 * s, 34 * s, 9 * s, 0.3
        logo.create_polygon(cx, cy - r, cx + r * k, cy - r * k, cx + r, cy,
                            cx + r * k, cy + r * k, cx, cy + r, cx - r * k, cy + r * k,
                            cx - r, cy, cx - r * k, cy - r * k, fill="#ffffff", outline="")
        logo.create_text(60 * s, 34 * s, text="ZeroJunk", anchor="w",
                         font=(FONT, 16, "bold"), fill=TEXT)

        self.nav = {}
        for name, title, icon in self.NAV:
            item = NavItem(sidebar, title, icon, lambda n=name: self.show(n),
                           self.scale, side_w - int(24 * self.scale))
            item.pack(pady=2)
            self.nav[name] = item

        # --- content: all views sit in the same cell; one is raised ---
        self.content = tk.Frame(self, bg=BG)
        self.content.pack(side="left", fill="both", expand=True,
                          padx=int(30 * self.scale), pady=int(24 * self.scale))
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=1)

        self.views = {}
        for name, view_class in (("main", MainView), ("uninstaller", UninstallerView),
                                 ("history", HistoryView)):
            view = view_class(self.content, self)
            view.grid(row=0, column=0, sticky="nsew")
            self.views[name] = view

        self.current = None
        self.show("main")

    def _setup_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")        # the only built-in theme that is fully colourable
        except tk.TclError:
            pass
        s = self.scale
        style.layout("ZJ.Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
        style.configure("ZJ.Treeview", background=CARD, fieldbackground=CARD,
                        foreground=TEXT, borderwidth=0, rowheight=int(28 * s),
                        font=(FONT, 10))
        style.configure("ZJ.Treeview.Heading", background="#f1f3f8", foreground=MUTED,
                        relief="flat", borderwidth=0, font=(FONT, 9, "bold"),
                        padding=(8, 5))
        style.map("ZJ.Treeview", background=[("selected", SELECT)],
                  foreground=[("selected", TEXT)])
        style.map("ZJ.Treeview.Heading", background=[("active", "#e4e8f2")])
        style.configure("ZJ.Vertical.TScrollbar", background="#c9ced9", troughcolor=CARD,
                        bordercolor=CARD, lightcolor="#c9ced9", darkcolor="#c9ced9",
                        arrowcolor=MUTED, relief="flat", gripcount=0)
        style.map("ZJ.Vertical.TScrollbar", background=[("active", "#aab1c0")])

    def report_callback_exception(self, exc, val, tb):
        """Tk swallows errors inside buttons. Show them instead, so a problem
        is never a silent blank window."""
        import traceback
        text = "".join(traceback.format_exception(exc, val, tb))
        write_crash_log(text)
        messagebox.showerror("ZeroJunk error", str(val))

    def show(self, name):
        """Raise one view and highlight its sidebar entry."""
        if self.current is not None and self.current != name:
            self.views[self.current].on_hide()
        self.current = name
        for key, item in self.nav.items():
            item.set_active(key == name)
        view = self.views[name]
        view.tkraise()
        view.on_show()

    def run_task(self, work, done):
        """Runs work() in a background thread, then calls done(ok, value)
        in the window thread (Tkinter must only be touched from there)."""
        results = queue.Queue()

        def worker():
            try:
                results.put((True, work()))
            except Exception as error:          # show any problem to the user
                results.put((False, error))

        def check():
            try:
                ok, value = results.get_nowait()
            except queue.Empty:
                self.after(50, check)           # not finished: look again soon
                return
            done(ok, value)

        threading.Thread(target=worker, daemon=True).start()
        self.after(50, check)

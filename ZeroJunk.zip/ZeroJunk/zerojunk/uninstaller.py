"""
uninstaller.py - everything the "App Uninstaller" tab needs, without any GUI.

    list_installed_apps()  reads the Windows Registry (Uninstall keys)
    deep_scan(app)         finds leftover cache / config folders of one app
    run_uninstall(app)     runs the app's own UninstallString
    delete_items(items)    removes the chosen leftovers (safely)
    write_log / combined_history   History tab support

The C backend (zerojunk_backend.exe) is NOT used here: it only knows the
Temp folder. Deleting is therefore guarded in this file by is_safe_target():
a path is only removed if it is deeper than a known user-data root (or is the
app's own install folder), is not a link, and is not a protected system folder.
"""

import ntpath
import os
import re
import stat
import subprocess
import time
from datetime import datetime

try:
    import winreg
except ImportError:                      # not Windows (only matters for tests)
    winreg = None

from . import bridge

UNINSTALL_PATH = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
UNINSTALL_LOG_NAME = "zerojunk_uninstall_log.txt"
REPARSE_POINT = 0x400                    # junctions, symlinks, cloud placeholders


# =====================================================
# Installed apps (Registry)
# =====================================================
def _value(key, name):
    try:
        return winreg.QueryValueEx(key, name)[0]
    except OSError:
        return None


def _text(value):
    return os.path.expandvars(str(value)).strip() if value not in (None, "") else ""


def _read_app(hive_name, hive, view_name, view, subkey):
    """One Uninstall sub-key -> app dictionary, or None if it is not a real
    desktop app (updates, system components, entries without an uninstaller)."""
    try:
        key = winreg.OpenKey(hive, UNINSTALL_PATH + "\\" + subkey, 0,
                             winreg.KEY_READ | view)
    except OSError:
        return None
    with key:
        name = _text(_value(key, "DisplayName"))
        uninstall = _text(_value(key, "UninstallString"))
        if not name or not uninstall:
            return None
        if _value(key, "SystemComponent") == 1:
            return None
        if _value(key, "ParentKeyName") or _value(key, "ParentDisplayName"):
            return None                       # an update of another program
        if str(_value(key, "ReleaseType") or "") in (
                "Security Update", "Update Rollup", "Hotfix", "Service Pack"):
            return None
        if re.match(r"(?i)^(KB\d{6,}|(security )?update for )", name):
            return None
        size_kb = _value(key, "EstimatedSize")
        return {
            "name": name,
            "publisher": _text(_value(key, "Publisher")),
            "version": _text(_value(key, "DisplayVersion")),
            "size_bytes": int(size_kb) * 1024 if isinstance(size_kb, int) else 0,
            "uninstall": uninstall,
            "install_location": _text(_value(key, "InstallLocation")),
            "icon": _text(_value(key, "DisplayIcon")),
            "hive_name": hive_name, "hive": hive,
            "view_name": view_name, "view": view,
            "subkey": subkey,
        }


def list_installed_apps():
    """HKLM + HKCU, 64-bit and 32-bit views. Sorted by name, duplicates removed."""
    if winreg is None:
        raise RuntimeError("The installed-app list needs the Windows Registry.")
    found = {}
    for hive_name, hive in (("HKLM", winreg.HKEY_LOCAL_MACHINE),
                            ("HKCU", winreg.HKEY_CURRENT_USER)):
        for view_name, view in (("64-bit", winreg.KEY_WOW64_64KEY),
                                ("32-bit", winreg.KEY_WOW64_32KEY)):
            try:
                root = winreg.OpenKey(hive, UNINSTALL_PATH, 0,
                                      winreg.KEY_READ | view)
            except OSError:
                continue
            with root:
                count = winreg.QueryInfoKey(root)[0]
                for index in range(count):
                    try:
                        subkey = winreg.EnumKey(root, index)
                    except OSError:
                        break
                    app = _read_app(hive_name, hive, view_name, view, subkey)
                    if app is None:
                        continue
                    ident = (app["name"].lower(), app["version"])
                    found.setdefault(ident, app)      # first one wins
    apps = sorted(found.values(), key=lambda a: a["name"].lower())
    for number, app in enumerate(apps):
        app["id"] = number
    return apps


def is_installed(app):
    """True while the app's Uninstall key still exists."""
    try:
        winreg.CloseKey(winreg.OpenKey(
            app["hive"], UNINSTALL_PATH + "\\" + app["subkey"], 0,
            winreg.KEY_READ | app["view"]))
        return True
    except OSError:
        return False


# =====================================================
# Names -> matching rules
# =====================================================
_CORP = {"inc", "ltd", "llc", "corp", "corporation", "co", "gmbh", "limited",
         "the", "company", "sa", "ag", "bv", "oy", "plc", "foundation", "org"}
_STOP = {"microsoft", "windows", "update", "setup", "driver", "drivers",
         "runtime", "redistributable", "desktop", "software", "program",
         "application", "tools", "player", "studio", "client", "service",
         "services", "launcher", "installer", "edition", "professional",
         "version", "framework", "extension", "language", "pack", "media"}
_GENERIC = {"cache", "logs", "data", "config", "settings", "updates", "update",
            "temp", "crashes", "crashpad", "installer", "setup", "common",
            "shared", "plugins", "packages", "assets", "resources", "storage"}
# never matched as "the app's own folder" (shared by many programs)
_SHARED_NAMES = {"microsoft", "windows", "temp", "tmp", "programs", "packages",
                 "common", "commonfiles", "system", "system32", "windowsapps",
                 "appdata", "local", "locallow", "roaming", "google", "adobe"}
_SHARED_PUBLISHERS = {"microsoft", "windows"}


def _norm(text):
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


class _Keys:
    """Search keys built from the app name and its publisher."""

    def __init__(self, name, publisher):
        clean = re.sub(r"\([^)]*\)|\[[^\]]*\]", " ", name or "")
        clean = re.sub(r"(?i)\bv?\d+(?:\.\d+)+\b", " ", clean)        # 1.2.3
        clean = re.sub(r"(?i)\b(x64|x86|64-?bit|32-?bit|amd64)\b", " ", clean)
        self.app = _norm(clean)
        pub_words = [w for w in re.split(r"[^A-Za-z0-9]+", publisher or "")
                     if w and w.lower() not in _CORP]
        pub_set = {_norm(w) for w in pub_words}
        self.pub = _norm("".join(pub_words))
        self.pub_first = _norm(pub_words[0]) if pub_words else ""
        self.words = {_norm(w) for w in re.split(r"[^A-Za-z0-9]+", clean)
                      if len(w) >= 5 and w.lower() not in _STOP
                      and _norm(w) not in pub_set}

    def usable(self):
        return len(self.app) >= 3 or bool(self.words)

    def is_app(self, n):
        """Top level: the folder IS this app (strict, the whole folder is removed)."""
        if not n or n in _SHARED_NAMES:
            return False
        if len(self.app) >= 3 and n == self.app:
            return True
        return len(self.app) >= 5 and self.app in n

    def is_publisher(self, n):
        return len(n) >= 3 and n in (self.pub, self.pub_first)

    def is_app_inside_publisher(self, n, parent):
        """Inside e.g. 'Mozilla\\': 'Firefox' belongs to 'Mozilla Firefox'."""
        if self.is_app(n) or n in self.words:
            return True
        return (parent not in _SHARED_PUBLISHERS and len(n) >= 4
                and n in self.app and n not in _GENERIC)


# =====================================================
# Deep scan
# =====================================================
def _env(name):
    return os.environ.get(name) or ""


def _norm_path(path):
    return ntpath.normcase(ntpath.normpath(path))


def _entry_is_link(entry):
    try:
        if entry.is_symlink():
            return True
        attributes = getattr(entry.stat(follow_symlinks=False),
                             "st_file_attributes", 0)
        return bool(attributes & REPARSE_POINT)
    except OSError:
        return True                  # cannot tell: treat as a link = leave alone


def _path_is_link(path):
    try:
        info = os.lstat(path)
    except OSError:
        return False
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & REPARSE_POINT)


def _scan_roots():
    """(label, folder) pairs where apps keep cache and settings."""
    profile = _env("USERPROFILE")
    local = _env("LOCALAPPDATA")
    candidates = [
        ("Local AppData", local),
        ("Local Programs", ntpath.join(local, "Programs") if local else ""),
        ("Roaming AppData", _env("APPDATA")),
        ("LocalLow", ntpath.join(profile, "AppData", "LocalLow") if profile else ""),
        ("ProgramData", _env("PROGRAMDATA")),
        ("Temp", _env("TEMP") or _env("TMP")),
    ]
    roots, seen = [], set()
    for label, folder in candidates:
        if folder and os.path.isdir(folder) and _norm_path(folder) not in seen:
            seen.add(_norm_path(folder))
            roots.append((label, folder))
    return roots


def _allowed_roots():
    profile = _env("USERPROFILE")
    folders = [_env("LOCALAPPDATA"), _env("APPDATA"), _env("PROGRAMDATA"),
               _env("TEMP"), _env("TMP"),
               ntpath.join(profile, "AppData") if profile else ""]
    return {_norm_path(f) for f in folders if f}


def _protected_set():
    profile = _env("USERPROFILE")
    folders = [_env("SystemRoot") or _env("WINDIR"), _env("ProgramFiles"),
               _env("ProgramFiles(x86)"), _env("ProgramW6432"),
               _env("CommonProgramFiles"), _env("CommonProgramFiles(x86)"),
               _env("ProgramData"), _env("ALLUSERSPROFILE"), profile,
               _env("LOCALAPPDATA"), _env("APPDATA"), _env("TEMP"), _env("TMP"),
               (_env("SystemDrive") + "\\") if _env("SystemDrive") else ""]
    if profile:
        folders.append(ntpath.dirname(profile))                    # C:\Users
        for sub in ("Desktop", "Documents", "Downloads", "Pictures", "Videos",
                    "Music", "OneDrive", "AppData", r"AppData\LocalLow",
                    r"AppData\Local\Programs"):
            folders.append(ntpath.join(profile, sub))
    for base in (_env("ProgramFiles"), _env("ProgramFiles(x86)")):
        if base:
            for sub in ("WindowsApps", "Windows NT", "Windows Defender",
                        "Common Files", "Microsoft", "Windows Mail"):
                folders.append(ntpath.join(base, sub))
    return {_norm_path(f) for f in folders if f}


def is_safe_target(path, kind="leftover"):
    """(True, "") if ZeroJunk may delete this path, else (False, reason).

    kind "leftover": must lie strictly INSIDE LocalAppData / AppData /
                     ProgramData / Temp.
    kind "install" : the app's install folder, at least two levels deep.
    Never allowed: drive roots, Windows, Program Files itself, the user
    profile and its standard folders, links, and ZeroJunk's own folder."""
    if not path or not ntpath.isabs(path):
        return False, "not a full path"
    norm = _norm_path(path)
    drive, rest = ntpath.splitdrive(norm)
    parts = [p for p in rest.split("\\") if p]
    if not drive or not parts:
        return False, "drive root"
    for protected in _protected_set():
        if norm == protected:
            return False, "protected folder"
        if protected.startswith(norm.rstrip("\\") + "\\"):
            return False, "contains a protected folder"
    windir = _env("SystemRoot")
    if windir and (norm == _norm_path(windir)
                   or norm.startswith(_norm_path(windir) + "\\")):
        return False, "Windows folder"
    own = _norm_path(bridge.APP_DIR)
    if own == norm or own.startswith(norm + "\\"):
        return False, "ZeroJunk's own folder"
    if kind == "install":
        if len(parts) < 2:
            return False, "too close to the drive root"
    elif not any(norm.startswith(root + "\\") for root in _allowed_roots()):
        return False, "outside the allowed folders"
    if _path_is_link(path):
        return False, "is a link"
    return True, ""


def folder_size(path):
    """(bytes, file count) of a folder. Links are not followed."""
    total = files = 0
    stack = [path]
    while stack:
        folder = stack.pop()
        try:
            iterator = os.scandir(folder)
        except OSError:
            continue
        with iterator:
            for entry in iterator:
                try:
                    if _entry_is_link(entry):
                        continue
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(entry.path)
                    else:
                        total += entry.stat(follow_symlinks=False).st_size
                        files += 1
                except OSError:
                    pass
    return total, files


def _matching_children(root, keys):
    found = []
    try:
        entries = list(os.scandir(root))
    except OSError:
        return found
    for entry in entries:
        n = _norm(entry.name)
        if not n or _entry_is_link(entry):
            continue
        if keys.is_app(n):
            found.append(entry.path)
        elif keys.is_publisher(n) and entry.is_dir(follow_symlinks=False):
            try:
                inner = list(os.scandir(entry.path))
            except OSError:
                continue
            for sub in inner:
                if not _entry_is_link(sub) and keys.is_app_inside_publisher(
                        _norm(sub.name), n):
                    found.append(sub.path)
    return found


def _clean_path(text):
    text = os.path.expandvars((text or "").strip().strip('"'))
    text = re.sub(r",\s*-?\d+$", "", text).strip().strip('"')      # icon index
    if len(text) > 3:
        text = text.rstrip("\\/")
    return text


def _exe_of(command):
    command = (command or "").strip()
    if command.startswith('"'):
        return command[1:].split('"', 1)[0]
    match = re.match(r"(?i)^(.*?\.exe)", command)
    return match.group(1) if match else ""


def _install_dir(app, keys):
    location = _clean_path(app.get("install_location"))
    if location and os.path.isdir(location):
        return location
    bases = {_norm_path(b) for b in (_env("ProgramFiles"), _env("ProgramFiles(x86)"),
                                     _env("ProgramW6432")) if b}
    if _env("LOCALAPPDATA"):
        bases.add(_norm_path(ntpath.join(_env("LOCALAPPDATA"), "Programs")))
    for source in (app.get("icon"), _exe_of(app.get("uninstall"))):
        exe = _clean_path(source)
        current = ntpath.dirname(exe) if exe else ""
        while current and ntpath.dirname(current) != current:
            parent = ntpath.dirname(current)
            if _norm_path(parent) in bases:           # first level under the base
                if keys.is_app(_norm(ntpath.basename(current))) \
                        and os.path.isdir(current):
                    return current
                break
            current = parent
    return None


def deep_scan(app):
    """Looks for leftover folders/files of one app. Nothing is changed.
    Returns {"items": [...], "bytes": n, "files": n}; each item has
    path, loc (where it was found), kind ("leftover"/"install"), bytes, files."""
    keys = _Keys(app["name"], app["publisher"])
    candidates = []                                   # (path, label, kind)

    install = _install_dir(app, keys)
    if install:
        candidates.append((install, "Install folder", "install"))
    if keys.usable():
        for label, root in _scan_roots():
            for path in _matching_children(root, keys):
                candidates.append((path, label, "leftover"))

    items, seen = [], set()
    for path, label, kind in candidates:
        norm = _norm_path(path)
        if norm in seen or not is_safe_target(path, kind)[0]:
            continue
        seen.add(norm)
        items.append({"path": os.path.normpath(path), "loc": label, "kind": kind})

    # drop anything that lies inside another item (it goes away with its parent)
    norms = [_norm_path(i["path"]) for i in items]
    items = [i for i, n in zip(items, norms)
             if not any(n != o and n.startswith(o + "\\") for o in norms)]

    for item in items:
        if os.path.isdir(item["path"]):
            item["bytes"], item["files"] = folder_size(item["path"])
        else:
            try:
                item["bytes"], item["files"] = os.stat(item["path"]).st_size, 1
            except OSError:
                item["bytes"], item["files"] = 0, 1
    items.sort(key=lambda i: i["bytes"], reverse=True)
    return {"items": items,
            "bytes": sum(i["bytes"] for i in items),
            "files": sum(i["files"] for i in items)}


# =====================================================
# Uninstall
# =====================================================
def _fix_command(command):
    command = os.path.expandvars(command.strip())
    # Some entries store "msiexec /I{GUID}" (modify); /X means uninstall.
    return re.sub(r"(?i)^(\s*\"?(?:[^\s\"]*\\)?msiexec(?:\.exe)?\"?\s+)/I", r"\1/X",
                  command, count=1)


def _run_elevated(command):
    """Asks Windows for administrator rights (UAC) and waits for the program."""
    import ctypes
    from ctypes import wintypes

    class SHELLEXECUTEINFOW(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("fMask", ctypes.c_ulong),
                    ("hwnd", wintypes.HWND), ("lpVerb", wintypes.LPCWSTR),
                    ("lpFile", wintypes.LPCWSTR), ("lpParameters", wintypes.LPCWSTR),
                    ("lpDirectory", wintypes.LPCWSTR), ("nShow", ctypes.c_int),
                    ("hInstApp", wintypes.HINSTANCE), ("lpIDList", ctypes.c_void_p),
                    ("lpClass", wintypes.LPCWSTR), ("hkeyClass", wintypes.HKEY),
                    ("dwHotKey", wintypes.DWORD), ("hIconOrMonitor", wintypes.HANDLE),
                    ("hProcess", wintypes.HANDLE)]

    info = SHELLEXECUTEINFOW()
    info.cbSize = ctypes.sizeof(info)
    info.fMask = 0x40                                  # SEE_MASK_NOCLOSEPROCESS
    info.lpVerb = "runas"
    info.lpFile = "cmd.exe"
    info.lpParameters = '/s /c "%s"' % command
    info.nShow = 0                                     # hide only cmd itself
    if not ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(info)):
        raise OSError("The administrator permission request was cancelled.")
    kernel = ctypes.windll.kernel32
    kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.WaitForSingleObject(info.hProcess, 0xFFFFFFFF)
    code = wintypes.DWORD()
    kernel.GetExitCodeProcess(info.hProcess, ctypes.byref(code))
    kernel.CloseHandle(info.hProcess)
    return code.value


def run_uninstall(app):
    """Runs the app's UninstallString and waits for it.
    Returns {"exit_code": int, "still_installed": bool}.
    Raises RuntimeError if the uninstaller could not be started."""
    command = _fix_command(app["uninstall"])
    try:
        try:
            exit_code = subprocess.run(command).returncode
        except OSError as error:
            if getattr(error, "winerror", None) != 740:    # needs administrator
                raise
            exit_code = _run_elevated(command)
    except OSError as error:
        raise RuntimeError("Could not start the uninstaller:\n%s\n\nCommand:\n%s"
                           % (error, command))

    # Many uninstallers hand over to a helper process and return at once:
    # give the registry up to 30 s to show the app is really gone.
    # (1602 / 1223 = the user cancelled: no need to wait.)
    if exit_code not in (1602, 1223):
        deadline = time.time() + 30
        while is_installed(app) and time.time() < deadline:
            time.sleep(1.0)
    return {"exit_code": exit_code, "still_installed": is_installed(app)}


# =====================================================
# Deleting leftovers
# =====================================================
def _why(error):
    if getattr(error, "winerror", None) == 32:
        return "in use by another program"
    if isinstance(error, PermissionError):
        return "access denied / protected"
    return error.strerror or str(error)


class _Stats:
    def __init__(self):
        self.bytes = 0
        self.files = 0
        self.errors = []


def _remove_file(path, size, stats):
    try:
        os.unlink(path)
    except FileNotFoundError:
        return
    except PermissionError:
        try:
            os.chmod(path, stat.S_IWRITE)               # read-only attribute
            os.unlink(path)
        except OSError as error:
            stats.errors.append((path, _why(error)))
            return
    except OSError as error:
        stats.errors.append((path, _why(error)))
        return
    stats.bytes += size
    stats.files += 1


def _remove_link(path, stats):
    """Deletes a symlink / junction itself. unlink / rmdir never follow it."""
    try:
        try:
            os.unlink(path)
        except (IsADirectoryError, PermissionError):
            os.rmdir(path)                              # directory link / junction
    except FileNotFoundError:
        pass
    except OSError as error:
        stats.errors.append((path, _why(error)))


def _delete_tree(path, stats, depth=0):
    if depth > 80:
        stats.errors.append((path, "folder is nested too deeply"))
        return
    try:
        entries = list(os.scandir(path))
    except FileNotFoundError:
        return
    except OSError as error:
        stats.errors.append((path, _why(error)))
        return
    for entry in entries:
        try:
            if _entry_is_link(entry):                   # remove the LINK only,
                _remove_link(entry.path, stats)         # never what it points to
            elif entry.is_dir(follow_symlinks=False):
                _delete_tree(entry.path, stats, depth + 1)
            else:
                _remove_file(entry.path,
                             entry.stat(follow_symlinks=False).st_size, stats)
        except OSError as error:
            stats.errors.append((entry.path, _why(error)))
    try:
        os.rmdir(path)
    except FileNotFoundError:
        pass
    except OSError as error:
        if os.path.exists(path):
            stats.errors.append((path, _why(error)))


def delete_items(items):
    """Deletes the given leftover items. Never raises for a locked file.
    Returns {"bytes", "files", "removed" (items fully gone), "failed": [(path, reason)]}."""
    total = _Stats()
    removed = 0
    failed = []
    for item in items:
        path = item["path"]
        safe, reason = is_safe_target(path, item.get("kind", "leftover"))
        if not safe:
            failed.append((path, "not deleted: " + reason))
            continue
        if not os.path.lexists(path):
            removed += 1                                # the uninstaller did it
            continue
        stats = _Stats()
        if os.path.isdir(path):
            _delete_tree(path, stats)
        else:
            try:
                size = os.stat(path).st_size
            except OSError:
                size = 0
            _remove_file(path, size, stats)
        total.bytes += stats.bytes
        total.files += stats.files
        if os.path.lexists(path):
            first = stats.errors[0] if stats.errors else (path, "could not be removed")
            failed.append((path, "%s (%s)" % (first[1], os.path.basename(first[0]))))
        else:
            removed += 1
    return {"bytes": total.bytes, "files": total.files,
            "removed": removed, "failed": failed}


# =====================================================
# History (separate log, so the backend's log and "Last cleaned" stay untouched)
# =====================================================
def uninstall_log_path():
    return os.path.join(os.path.dirname(bridge.log_path()), UNINSTALL_LOG_NAME)


def write_log(text):
    """Appends 'text on: <time>'. Returns True if saved."""
    try:
        path = uninstall_log_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as file:
            file.write("%s on: %s\n" % (text.replace("\n", " "), time.ctime()))
        return True
    except OSError:
        return False


def _read_lines(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as file:
            return [line.strip() for line in file if line.strip()][::-1]
    except OSError:
        return []


def _when(line):
    text = " ".join(line.partition(" on: ")[2].split())
    try:
        return datetime.strptime(text, "%a %b %d %H:%M:%S %Y")
    except ValueError:
        return datetime.min


def combined_history():
    """[(line, kind)] newest first; kind is 'junk' (C backend) or 'uninstall'."""
    entries = []
    for index, line in enumerate(bridge.read_history()):
        entries.append((_when(line), -index, line, "junk"))
    for index, line in enumerate(_read_lines(uninstall_log_path())):
        entries.append((_when(line), -index, line, "uninstall"))
    entries.sort(key=lambda e: (e[0], e[1]), reverse=True)
    return [(line, kind) for _, _, line, kind in entries]

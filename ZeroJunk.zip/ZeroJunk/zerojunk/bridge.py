"""
bridge.py - the ONLY file that talks to the C backend.

The GUI never deletes anything itself. It starts
zerojunk_backend.exe with --scan or --clean --yes-delete, reads the single
"RESULT ..." line the C program prints, and turns it into a
Python dictionary. All safety checks stay inside the C code.
"""

import os
import subprocess
import sys

BACKEND_NAME = "zerojunk_backend.exe"
LOG_NAME = "zerojunk_log.txt"      # the C program writes this file


def log_path():
    """Same file the C backend writes: %LOCALAPPDATA%\\ZeroJunk\\zerojunk_log.txt
    (a folder the user can always write to, also when installed in Program Files)."""
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "ZeroJunk", LOG_NAME)


def _app_folder():
    """Folder that holds the program.
    - built .exe : the folder that contains ZeroJunk.exe
    - plain python: the project folder (one level above this file)"""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


APP_DIR = _app_folder()


class BackendError(Exception):
    """Raised when the C backend is missing, fails, or refuses to run."""


def find_backend():
    """Returns the full path of zerojunk_backend.exe, or None."""
    folders = [APP_DIR, os.path.join(APP_DIR, "backend")]
    bundled = getattr(sys, "_MEIPASS", None)      # PyInstaller data folder
    if bundled:
        folders.insert(0, bundled)
    for folder in folders:
        path = os.path.join(folder, BACKEND_NAME)
        if os.path.isfile(path):
            return path
    return None


def _parse_result(line):
    """'RESULT files=3 bytes=1024 ...' -> {'files': 3, 'bytes': 1024, ...}"""
    values = {}
    for part in line[len("RESULT "):].split():
        key, _, number = part.partition("=")
        values[key] = int(number)
    return {
        "files": values["files"],
        "bytes": values["bytes"],
        "skipped": values["skipped"],
        "incomplete": values["incomplete"] == 1,
        "log_saved": values["log"] == 1,
    }


def _run(*options):
    """Runs the backend with the given options and returns its parsed result."""
    exe = find_backend()
    if exe is None:
        raise BackendError(
            BACKEND_NAME + " was not found.\nBuild it first (see README.md).")

    try:
        done = subprocess.run(
            [exe, *options],
            stdin=subprocess.DEVNULL,   # never wait for typing: no input = no delete
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=APP_DIR,
            timeout=900,           # stop after 15 minutes
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except subprocess.TimeoutExpired:
        raise BackendError("The backend took too long and was stopped.")
    except OSError as error:
        raise BackendError("Could not start the backend:\n" + str(error))

    result_line = None
    for line in done.stdout.splitlines():
        if line.startswith("RESULT "):
            result_line = line

    # Any problem: show the backend's own message (e.g. "TEMP goes
    # through a link...") so the user sees the real reason.
    if done.returncode != 0 or result_line is None:
        message = done.stdout.strip() or "The backend gave no answer."
        raise BackendError(message)

    try:
        return _parse_result(result_line)
    except (KeyError, ValueError):
        raise BackendError("The backend answer could not be understood:\n"
                           + result_line)


def scan():
    """Look only. Nothing is deleted."""
    return _run("--scan")


def clean():
    """Deletes files. The GUI must ask the user BEFORE calling this.
    --yes-delete tells the backend that the question was already asked
    (run by hand, the backend asks the user to type DELETE itself)."""
    return _run("--clean", "--yes-delete")


def format_size(number_of_bytes):
    """Same style as the C function printSize(): bytes, KB, MB, GB."""
    if number_of_bytes < 1024:
        return "%d bytes" % number_of_bytes
    if number_of_bytes < 1024 ** 2:
        return "%.2f KB" % (number_of_bytes / 1024)
    if number_of_bytes < 1024 ** 3:
        return "%.2f MB" % (number_of_bytes / 1024 ** 2)
    return "%.2f GB" % (number_of_bytes / 1024 ** 3)


def read_history():
    """Lines of the cleaning log, newest first. Empty list if no log yet."""
    try:
        with open(log_path(), "r", encoding="utf-8", errors="replace") as file:
            lines = [line.strip() for line in file if line.strip()]
    except OSError:
        return []
    return list(reversed(lines))


def last_cleaned():
    """Text like 'Tue Nov 24 10:00:00 2026', or None if never cleaned."""
    history = read_history()
    if not history:
        return None
    return history[0].partition(" on: ")[2] or history[0]

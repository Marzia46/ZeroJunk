@echo off
REM ZeroJunk - installs the 3 build tools with winget (x64 versions, for Windows 10/11 x64 or ARM64).
REM Run once, then CLOSE this window, open a new one, and run build.bat.
where winget >nul 2>nul || (echo ERROR: winget not found. Install "App Installer" from the Microsoft Store. & pause & exit /b 1)

echo [1/3] Python 3.12 x64...
winget install -e --id Python.Python.3.12 --architecture x64 --scope user --accept-package-agreements --accept-source-agreements
echo [2/3] Inno Setup 6...
winget install -e --id JRSoftware.InnoSetup --accept-package-agreements --accept-source-agreements
echo [3/3] MSYS2 + 64-bit gcc...
winget install -e --id MSYS2.MSYS2 --accept-package-agreements --accept-source-agreements
if not exist "C:\msys64\usr\bin\bash.exe" (echo ERROR: MSYS2 was not found in C:\msys64. & pause & exit /b 1)
REM The first -Syu may stop after updating core packages, so it runs twice.
"C:\msys64\usr\bin\bash.exe" -lc "pacman -Syu --noconfirm"
"C:\msys64\usr\bin\bash.exe" -lc "pacman -Syu --noconfirm"
"C:\msys64\usr\bin\bash.exe" -lc "pacman -S --needed --noconfirm mingw-w64-ucrt-x86_64-gcc"
if not exist "C:\msys64\ucrt64\bin\gcc.exe" (echo ERROR: x64 gcc was not installed. Run this file again. & pause & exit /b 1)

echo.
echo Done. Close this window, open a new one, then double-click build.bat.
pause

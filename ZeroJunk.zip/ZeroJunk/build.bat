@echo off
REM ZeroJunk - one-click build for Windows 10/11 x64 and Windows 11 ARM64 (x64 tools).
REM Needs: Python 3.12 x64 with Tcl/Tk (found with "py -3.12"), MinGW-w64 gcc (64-bit x86_64).
REM Optional: Inno Setup 6.3+ (if ISCC.exe is missing, the installer step is skipped).
REM Output: dist\ZeroJunk\ZeroJunk.exe, and release\ZeroJunk_Setup.exe when Inno Setup is installed.
REM Windows 11 ARM: build with x64 Python + x64 MinGW. The result is an x64 app that runs under Windows' built-in emulation.
if not defined ZJ_INNER (
  set ZJ_INNER=1
  cmd /c ""%~f0""
  echo.
  pause
  exit /b
)
setlocal EnableExtensions
cd /d "%~dp0"
if exist "C:\msys64\mingw64\bin\gcc.exe" set "PATH=C:\msys64\mingw64\bin;%PATH%"
if exist "C:\msys64\ucrt64\bin\gcc.exe" set "PATH=C:\msys64\ucrt64\bin;%PATH%"

echo [1/5] Checking tools...
where gcc >nul 2>nul || (echo ERROR: gcc not found. Run install_tools.bat, or add MinGW-w64 x64 to PATH. & exit /b 1)
gcc -dumpmachine | findstr /i "x86_64" >nul || (echo ERROR: gcc must be 64-bit x86_64. ARM64 gcc is NOT ok. Run install_tools.bat. & exit /b 1)

REM --- Python: "py -3.12" must be x64 (win-amd64) and must have a working Tcl/Tk ---
set "PYEXE="
set "PYSEEN="
set "PYTKBAD="
for %%V in (3.12 3.12-64) do if not defined PYEXE call :try_py %%V
if not defined PYEXE goto :no_python
echo Using Python: %PYEXE%
"%PYEXE%" --version

"%PYEXE%" -m pip install --quiet --upgrade pyinstaller || (echo ERROR: could not install PyInstaller. & exit /b 1)

REM --- Inno Setup is optional: no ISCC.exe = no installer, but the app is still built ---
set "ISCC="
where iscc >nul 2>nul && set "ISCC=iscc"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not defined ISCC echo WARNING: Inno Setup 6 ^(ISCC.exe^) not found. The installer step will be skipped.

echo [2/5] Building the C backend...
if exist backend\zerojunk_backend.exe del /q backend\zerojunk_backend.exe
gcc -Os -s -Wall -static backend\zerojunk_simple_v6.c -o backend\zerojunk_backend.exe || (echo ERROR: C build failed. & exit /b 1)
if not exist backend\zerojunk_backend.exe (echo ERROR: backend exe was not created. & exit /b 1)

echo [3/5] Testing with FAKE Temp folders only...
"%PYEXE%" tests\test_bridge.py || (echo ERROR: bridge tests failed. & exit /b 1)
"%PYEXE%" tests\test_backend_fake_temp.py || (echo ERROR: backend tests failed. & exit /b 1)

echo [4/5] Building ZeroJunk.exe with PyInstaller...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
"%PYEXE%" -m PyInstaller --noconfirm --clean --windowed --onedir --name ZeroJunk ^
  --add-binary "backend\zerojunk_backend.exe;." main.py || (echo ERROR: PyInstaller failed. & exit /b 1)
if not exist dist\ZeroJunk\ZeroJunk.exe (echo ERROR: dist\ZeroJunk\ZeroJunk.exe was not created. & exit /b 1)

echo [5/5] Building the installer with Inno Setup...
if not defined ISCC goto :skip_installer
if exist release\ZeroJunk_Setup.exe del /q release\ZeroJunk_Setup.exe
"%ISCC%" installer\ZeroJunk.iss || (echo ERROR: Inno Setup failed. & exit /b 1)
if not exist release\ZeroJunk_Setup.exe (echo ERROR: release\ZeroJunk_Setup.exe was not created. & exit /b 1)

echo.
echo DONE.
echo Application: %CD%\dist\ZeroJunk\ZeroJunk.exe
echo Installer  : %CD%\release\ZeroJunk_Setup.exe
endlocal
exit /b 0

:skip_installer
echo SKIPPED: ISCC.exe was not found, so no installer was built.
echo.
echo DONE ^(application only^).
echo Application: %CD%\dist\ZeroJunk\ZeroJunk.exe
echo To also build release\ZeroJunk_Setup.exe: install Inno Setup 6, then run build.bat again.
endlocal
exit /b 0

:no_python
if not defined PYSEEN goto :np_missing
if defined PYTKBAD goto :np_tk
echo ERROR: "py -3.12" found Python 3.12 but it is not x64 ^(win-amd64^). ARM64 Python is NOT ok. Run install_tools.bat.
exit /b 1
:np_missing
echo ERROR: "py -3.12" did not find Python 3.12. Run install_tools.bat, then open a NEW window.
exit /b 1
:np_tk
echo ERROR: Python 3.12 x64 was found but tkinter/Tcl does not work. Reinstall it with install_tools.bat.
exit /b 1

:try_py
set "CAND="
for /f "usebackq delims=" %%P in (`py -%1 -c "import sys;print(sys.executable)" 2^>nul`) do set "CAND=%%P"
if not defined CAND exit /b 0
set "PYSEEN=1"
"%CAND%" -c "import sys,sysconfig;sys.exit(0 if sysconfig.get_platform()=='win-amd64' and sys.maxsize>2**32 else 1)" >nul 2>nul || exit /b 0
"%CAND%" -c "import tkinter;tkinter.Tcl().eval('info patchlevel')" >nul 2>nul || (set "PYTKBAD=1" & exit /b 0)
set "PYEXE=%CAND%"
exit /b 0

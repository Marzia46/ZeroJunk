"""Tests for zerojunk/bridge.py. Run: python tests/test_bridge.py
Uses a FAKE backend (a .bat file on Windows, a shell script elsewhere) and a fake
history folder. Touches no real Temp."""
import os, shutil, stat, sys, tempfile, unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from zerojunk import bridge

IS_WIN = sys.platform == "win32"


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="zj_fake_")
        self.old_local = os.environ.get("LOCALAPPDATA")
        os.environ["LOCALAPPDATA"] = self.tmp
        self.old_dir = bridge.APP_DIR
        self.old_name = bridge.BACKEND_NAME
        bridge.APP_DIR = self.tmp
        if IS_WIN:      # a .exe must be a real program, so the fake one is a .bat
            bridge.BACKEND_NAME = "zerojunk_fake_backend.bat"

    def tearDown(self):
        bridge.APP_DIR = self.old_dir
        bridge.BACKEND_NAME = self.old_name
        if self.old_local is None:
            os.environ.pop("LOCALAPPDATA", None)
        else:
            os.environ["LOCALAPPDATA"] = self.old_local
        shutil.rmtree(self.tmp, ignore_errors=True)

    def fake_backend(self, sh_body, bat_body):
        path = os.path.join(self.tmp, bridge.BACKEND_NAME)
        if IS_WIN:
            with open(path, "w", newline="") as f:
                f.write("@echo off\r\n" + bat_body.replace("\n", "\r\n") + "\r\n")
        else:
            with open(path, "w") as f:
                f.write("#!/bin/sh\n" + sh_body + "\n")
            os.chmod(path, os.stat(path).st_mode | stat.S_IEXEC)

    def test_parse_and_scan(self):
        line = "RESULT files=3 bytes=2048 skipped=1 incomplete=0 log=1"
        self.fake_backend('echo "%s"' % line, "echo " + line)
        r = bridge.scan()
        self.assertEqual((r["files"], r["bytes"], r["skipped"]), (3, 2048, 1))
        self.assertFalse(r["incomplete"])

    def test_backend_refusal_shows_message(self):
        self.fake_backend('echo "Error: TEMP goes through a link"; exit 1',
                          "echo Error: TEMP goes through a link\nexit /b 1")
        with self.assertRaises(bridge.BackendError) as c:
            bridge.scan()
        self.assertIn("link", str(c.exception))

    def test_missing_backend(self):
        with self.assertRaises(bridge.BackendError):
            bridge.scan()

    def test_clean_passes_yes_delete(self):
        line = "RESULT files=1 bytes=1 skipped=0 incomplete=0 log=1"
        self.fake_backend(
            '[ "$1 $2" = "--clean --yes-delete" ] && echo "%s" || exit 2' % line,
            'if "%~1 %~2"=="--clean --yes-delete" (\n  echo ' + line + '\n) else (\n  exit /b 2\n)')
        self.assertEqual(bridge.clean()["files"], 1)

    def test_history_location_and_order(self):
        self.assertEqual(bridge.read_history(), [])
        os.makedirs(os.path.join(self.tmp, "ZeroJunk"))
        with open(bridge.log_path(), "w") as f:
            f.write("Cleaned on: Mon Nov 23 10:00:00 2026\nCleaned on: Tue Nov 24 10:00:00 2026\n")
        self.assertTrue(bridge.read_history()[0].endswith("Nov 24 10:00:00 2026"))
        self.assertEqual(bridge.last_cleaned(), "Tue Nov 24 10:00:00 2026")

    def test_format_size(self):
        self.assertEqual(bridge.format_size(10), "10 bytes")
        self.assertEqual(bridge.format_size(1536), "1.50 KB")
        self.assertEqual(bridge.format_size(3 * 1024 ** 3), "3.00 GB")


if __name__ == "__main__":
    unittest.main(verbosity=2)

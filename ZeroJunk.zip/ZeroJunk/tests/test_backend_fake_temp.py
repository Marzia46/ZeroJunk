"""Backend safety tests on FAKE Temp folders only (Windows only).
Run: python tests/test_backend_fake_temp.py   (build backend\\zerojunk_backend.exe first)
The real Temp folder is never used: TEMP, TMP and LOCALAPPDATA point into a throw-away folder."""
import os, shutil, subprocess, sys, tempfile, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, "backend", "zerojunk_backend.exe")


def write(path, size=100):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"x" * size)


@unittest.skipUnless(sys.platform == "win32", "Windows only")
class FakeTempTests(unittest.TestCase):
    def setUp(self):
        self.base = os.path.realpath(tempfile.mkdtemp(prefix="zj_fake_"))
        self.local = os.path.join(self.base, "AppData", "Local")
        self.temp = os.path.join(self.local, "Temp")
        self.outside = os.path.join(self.base, "Documents", "keep.txt")
        write(os.path.join(self.temp, "a.tmp"))
        write(os.path.join(self.temp, "sub", "b.tmp"), 200)
        write(self.outside)

    def tearDown(self):
        shutil.rmtree(self.base, ignore_errors=True)

    def run_exe(self, *args, temp=None, stdin=subprocess.DEVNULL):
        env = dict(os.environ, TEMP=temp or self.temp, TMP=temp or self.temp,
                   LOCALAPPDATA=self.local)
        return subprocess.run([EXE, *args], env=env, stdin=stdin,
                              capture_output=True, text=True, timeout=60)

    def test_scan_counts_and_deletes_nothing(self):
        r = self.run_exe("--scan")
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIn("RESULT files=2 bytes=300", r.stdout)
        self.assertTrue(os.path.exists(os.path.join(self.temp, "a.tmp")))

    def test_clean_deletes_only_temp_and_writes_log(self):
        r = self.run_exe("--clean", "--yes-delete")
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIn("RESULT files=2 bytes=300", r.stdout)
        self.assertFalse(os.path.exists(os.path.join(self.temp, "a.tmp")))
        self.assertTrue(os.path.exists(self.outside))
        self.assertTrue(os.path.isfile(os.path.join(self.local, "ZeroJunk", "zerojunk_log.txt")))

    def test_clean_without_confirmation_deletes_nothing(self):
        r = self.run_exe("--clean")            # input closed = no
        self.assertEqual(r.returncode, 3, r.stdout)
        self.assertTrue(os.path.exists(os.path.join(self.temp, "a.tmp")))

    def test_refuses_folder_not_named_temp(self):
        r = self.run_exe("--clean", "--yes-delete", temp=os.path.join(self.base, "Documents"))
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertTrue(os.path.exists(self.outside))

    def test_junction_inside_temp_is_not_followed(self):
        link = os.path.join(self.temp, "link")
        made = subprocess.run(["cmd", "/c", "mklink", "/J", link, os.path.dirname(self.outside)],
                              capture_output=True, text=True)
        self.assertEqual(made.returncode, 0, made.stdout + made.stderr)
        self.run_exe("--clean", "--yes-delete")
        self.assertTrue(os.path.exists(self.outside))

    def test_bad_option_refused(self):
        self.assertEqual(self.run_exe("--scan", "--yes-delete").returncode, 2)
        self.assertEqual(self.run_exe("--bogus").returncode, 2)


if __name__ == "__main__":
    if sys.platform == "win32" and not os.path.isfile(EXE):
        sys.exit("Build backend\\zerojunk_backend.exe first.")
    unittest.main(verbosity=2)

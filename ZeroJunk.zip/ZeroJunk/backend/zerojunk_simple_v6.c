/* =====================================================
   ZeroJunk - Simple Junk File Cleaner (Windows x64)  -  v6
   -----------------------------------------------------
   Build:  gcc -Os -s zerojunk_simple_v6.c -o zerojunk_backend.exe

   How it works:
     1. isTempSafe() asks Windows for the real Temp folder
        and checks it carefully.
     2. walkFolder() goes through that folder (and its
        subfolders) using the Windows file-search functions.
        It is used for both Scan and Clean.
     3. Clean scans first, asks "y/n", then walks the folder
        again to delete, so nothing old is ever reused.

   What is new in v5 (safety fixes only):
     - The Temp path comes from Windows (GetTempPath) and is
       resolved to its REAL location. If a junction or
       symlink changes where it points, it is refused.
     - Links (junctions / symlinks) are never entered and
       never deleted.
     - system() and the "dir" command are gone, so no
       command line can be tricked. The old list file is
       gone too, so it can never be stale or half-written.
     - Success messages are only shown when it really worked.

   What is new in v6 (installed-app fixes):
     - The history log is now saved in %LOCALAPPDATA%\\ZeroJunk\\zerojunk_log.txt
       (a folder the user can always write to), not next to the
       program (Program Files is read-only for normal users).
     - The log is never inside Temp, so the old "skip the log
       file" rule in walkFolder() was removed.

   GUI mode (added for the Python app; the menu is unchanged):
     zerojunk_backend.exe --scan                look only, prints ONE "RESULT" line
     zerojunk_backend.exe --clean               scans, then asks you to type
                                                DELETE before anything is deleted
     zerojunk_backend.exe --clean --yes-delete  deletes with NO question (the
                                                GUI uses this, because it has
                                                already asked the user)
   Started with no arguments, the menu works exactly as before.
   Running --clean by hand is safe: if you do not type DELETE
   (or the input is closed), nothing is deleted.
   ===================================================== */

#define _WIN32_WINNT 0x0600     /* needed for GetFinalPathNameByHandle */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>      /* isalpha() checks for a drive letter */
#include <time.h>

#define LOG_FILE   "zerojunk_log.txt"   /* cleaning history */
#define MAX_PATH_TXT 520                /* size of every path buffer */
#define MAX_DEPTH  64                   /* deepest subfolder level we enter */

/* Results shared by the functions.
   unsigned long long = a very big whole number
   (a normal int overflows at 2 GB). */
unsigned long long totalBytes;   /* size of files counted / deleted */
int fileCount;                   /* files counted / deleted */
int skipped;                     /* files / links that were left alone */
int incomplete;                  /* 1 = something could not be read, so
                                    the numbers may be too low */

/* The Temp folder AFTER it passed every safety check.
   Only isTempSafe() writes to it. Other functions only read it. */
char safeTemp[MAX_PATH_TXT];

/* -----------------------------------------------------
   Function: clearInput
   Purpose : Throws away extra characters the user typed,
             so they do not confuse the next scanf().
   ----------------------------------------------------- */
void clearInput() {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {
        /* do nothing: we just read and ignore the characters */
    }
}

/* -----------------------------------------------------
   Function: printSize
   Purpose : Prints a size as bytes, KB, MB or GB.
   ----------------------------------------------------- */
void printSize(unsigned long long b) {
    /* 1 KB = 1024 bytes
       1 MB = 1024 x 1024 = 1048576 bytes
       1 GB = 1024 x 1024 x 1024 = 1073741824 bytes */
    if (b < 1024ULL)                    printf("%llu bytes", b);
    else if (b < 1024ULL * 1024)        printf("%.2f KB", b / 1024.0);
    else if (b < 1024ULL * 1024 * 1024) printf("%.2f MB", b / 1048576.0);
    else                                printf("%.2f GB", b / 1073741824.0);
}

/* -----------------------------------------------------
   Function: removeTrailingSlashes
   Purpose : "C:\Windows\Temp\" becomes "C:\Windows\Temp".
             The first 3 characters ("C:\") are never cut.
   ----------------------------------------------------- */
void removeTrailingSlashes(char *text) {
    size_t len = strlen(text);
    while (len > 3 && text[len - 1] == '\\') {
        text[len - 1] = '\0';
        len--;
    }
}

/* -----------------------------------------------------
   Function: isTempSafe
   Purpose : Safety check. Finds the real Temp folder and
             decides if it is safe, BEFORE anything is
             scanned or deleted. If it passes, the real
             path is saved in safeTemp.
             Returns 1 if safe, 0 if not safe.

   The rules, in order (any failure = stop, nothing touched):
     1. Ask Windows for the Temp folder (GetTempPath) and
        turn it into one full, long-name path.
     2. It must exist and be a folder.
     3. Open the folder and ask Windows for its REAL path.
        If the real path is different, a junction or symlink
        is in the way -> refuse.
     4. It must be a full local path like C:\ (not a network
        path, not a drive root).
     5. The LAST folder name must be exactly "Temp" or "Tmp".
   ----------------------------------------------------- */
int isTempSafe() {
    char raw[MAX_PATH_TXT];       /* path as Windows gives it */
    char full[MAX_PATH_TXT];      /* full path (no "." or "..") */
    char longPath[MAX_PATH_TXT];  /* same, with short 8.3 names expanded */
    char real[MAX_PATH_TXT];      /* the REAL location on disk */
    char *p;                      /* real path without the "\\?\" start */
    char *lastSlash;
    DWORD n, attr;
    HANDLE h;

    /* Rule 1: every call returns 0 on error, or a number that is
       too big for our buffer. Both mean "stop". */
    n = GetTempPathA(sizeof(raw), raw);
    if (n == 0 || n >= sizeof(raw)) goto fail_path;
    n = GetFullPathNameA(raw, sizeof(full), full, NULL);
    if (n == 0 || n >= sizeof(full)) goto fail_path;
    removeTrailingSlashes(full);
    n = GetLongPathNameA(full, longPath, sizeof(longPath));
    if (n == 0 || n >= sizeof(longPath)) goto fail_path;
    removeTrailingSlashes(longPath);

    /* Rule 2: must exist and be a folder. */
    attr = GetFileAttributesA(longPath);
    if (attr == INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY)) {
        printf("Error: The Temp folder does not exist. Nothing was touched.\n");
        return 0;
    }

    /* Rule 3: open the folder (this follows any link) and ask
       Windows where it REALLY is. FILE_FLAG_BACKUP_SEMANTICS is
       required to open a folder. */
    h = CreateFileA(longPath, 0,
                    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                    NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
    if (h == INVALID_HANDLE_VALUE) goto fail_path;
    n = GetFinalPathNameByHandleA(h, real, sizeof(real), FILE_NAME_NORMALIZED);
    CloseHandle(h);
    if (n == 0 || n >= sizeof(real)) goto fail_path;

    /* Windows writes the real path as "\\?\C:\...". Cut off the
       4-character "\\?\" start. A network path starts with
       "\\?\UNC\" and is refused by Rule 4 below. */
    if (strncmp(real, "\\\\?\\", 4) != 0) goto fail_path;
    p = real + 4;
    removeTrailingSlashes(p);

    if (_stricmp(p, longPath) != 0) {   /* _stricmp ignores upper/lower case */
        printf("Error: TEMP goes through a link or shortcut. Nothing was touched.\n");
        return 0;
    }

    /* Rule 4: local drive letter, and more than just "C:\". */
    if (!isalpha((unsigned char)p[0]) || p[1] != ':' || p[2] != '\\' || strlen(p) <= 3) {
        printf("Error: TEMP is not a normal local folder. Nothing was touched.\n");
        return 0;
    }

    /* Rule 5: the last folder name must be exactly Temp or Tmp.
       strrchr finds the LAST '\'. It cannot be NULL: Rule 4
       proved there is a '\' at position 2. */
    lastSlash = strrchr(p, '\\');
    if (_stricmp(lastSlash + 1, "Temp") != 0 && _stricmp(lastSlash + 1, "Tmp") != 0) {
        printf("Error: The last folder of TEMP is not \"Temp\" or \"Tmp\". Nothing was touched.\n");
        return 0;
    }

    strcpy(safeTemp, p);   /* fits: p is shorter than MAX_PATH_TXT */
    return 1;

fail_path:
    printf("Error: Could not read a safe Temp folder. Nothing was touched.\n");
    return 0;
}

/* -----------------------------------------------------
   Function: walkFolder
   Purpose : Goes through ONE folder, then its subfolders.
             For every normal file it counts the file and
             adds its size.

   The parameter doDelete is a FLAG (0 or 1, like a switch):
       doDelete = 0 -> LOOK ONLY (used by Scan)
       doDelete = 1 -> LOOK AND DELETE (used by Clean)
                       only files that were really deleted
                       are counted.

   Safety rules inside:
       - a junction or symlink is NEVER entered or deleted,
         so we cannot leave the Temp folder,
       - folders are never deleted, only files,
       - if something cannot be read (access denied, path too
         long, too deep), "incomplete" is set to 1 so the
         messages do not claim everything went fine.
   ----------------------------------------------------- */
void walkFolder(const char *folder, int doDelete, int depth) {
    char pattern[MAX_PATH_TXT];   /* "folder\*" = every item in the folder */
    char path[MAX_PATH_TXT];      /* full path of the current item */
    WIN32_FIND_DATAA item;        /* facts about the current item */
    HANDLE h;

    if (depth > MAX_DEPTH || strlen(folder) + 3 >= MAX_PATH_TXT) {
        incomplete = 1;
        return;
    }

    sprintf(pattern, "%s\\*", folder);   /* fits: length checked above */
    h = FindFirstFileA(pattern, &item);
    if (h == INVALID_HANDLE_VALUE) {
        incomplete = 1;   /* could not open this folder */
        return;
    }

    do {
        /* "." and ".." mean "this folder" and "the folder above" */
        if (strcmp(item.cFileName, ".") == 0 || strcmp(item.cFileName, "..") == 0) {
            continue;
        }

        if (strlen(folder) + 1 + strlen(item.cFileName) >= MAX_PATH_TXT) {
            skipped++;
            incomplete = 1;
            continue;
        }
        sprintf(path, "%s\\%s", folder, item.cFileName);

        /* Links: do not follow, do not delete. */
        if (item.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) {
            skipped++;
            continue;
        }

        /* Real subfolder: go inside. */
        if (item.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            walkFolder(path, doDelete, depth + 1);
            continue;
        }

        /* DeleteFile returns non-zero only if the file was really
           deleted. If it fails (file is locked or protected), skip it. */
        if (doDelete && !DeleteFileA(path)) {
            skipped++;
            continue;
        }

        fileCount++;
        /* size = high part * 2^32 + low part */
        totalBytes += ((unsigned long long)item.nFileSizeHigh << 32) | item.nFileSizeLow;

    } while (FindNextFileA(h, &item));

    /* FindNextFile also returns 0 when reading FAILS, not only at the
       end. ERROR_NO_MORE_FILES is the normal end. */
    if (GetLastError() != ERROR_NO_MORE_FILES) {
        incomplete = 1;
    }
    FindClose(h);
}

/* -----------------------------------------------------
   Function: startWalk
   Purpose : Clears the counters, checks Temp is safe, then
             walks it. Returns 1 if the walk ran, 0 if the
             Temp folder was not safe (nothing was touched).
   ----------------------------------------------------- */
int startWalk(int doDelete) {
    totalBytes = 0;
    fileCount = 0;
    skipped = 0;
    incomplete = 0;

    if (!isTempSafe()) {
        return 0;
    }
    walkFolder(safeTemp, doDelete, 0);
    return 1;
}

/* -----------------------------------------------------
   Function: getLogPath
   Purpose : Builds  %LOCALAPPDATA%\\ZeroJunk\\zerojunk_log.txt  and
             creates the ZeroJunk folder if needed.
             Returns 1 if the path is ready, 0 if not.
   ----------------------------------------------------- */
int getLogPath(char *out, size_t size) {
    char base[MAX_PATH_TXT];
    DWORD n = GetEnvironmentVariableA("LOCALAPPDATA", base, sizeof(base));

    if (n == 0 || n >= sizeof(base)) {
        return 0;
    }
    removeTrailingSlashes(base);
    if (!isalpha((unsigned char)base[0]) || base[1] != ':' || base[2] != '\\') {
        return 0;   /* must be a normal full path */
    }
    if (strlen(base) + strlen("\\ZeroJunk\\") + strlen(LOG_FILE) + 1 > size) {
        return 0;
    }
    sprintf(out, "%s\\ZeroJunk", base);
    if (!CreateDirectoryA(out, NULL) && GetLastError() != ERROR_ALREADY_EXISTS) {
        return 0;
    }
    strcat(out, "\\" LOG_FILE);
    return 1;
}

/* -----------------------------------------------------
   Function: writeLog
   Purpose : Adds one line with the current time to the log.
             Used by the menu Clean and by --clean.
             Returns 1 if it was saved, 0 if not.
   ----------------------------------------------------- */
int writeLog() {
    char logPath[MAX_PATH_TXT];
    FILE *fp;
    time_t now;

    if (!getLogPath(logPath, sizeof(logPath))) {
        return 0;
    }
    fp = fopen(logPath, "a");          /* "a" = append, old logs are kept */
    if (fp == NULL) {
        return 0;
    }
    time(&now);                                    /* get current time */
    fprintf(fp, "%s on: %s", incomplete ? "Partly cleaned" : "Cleaned",
            ctime(&now));                          /* ctime() text ends with '\n' */
    return fclose(fp) == 0;                        /* fclose can fail when saving */
}

/* -----------------------------------------------------
   Function: scanJunk
   Purpose : Menu 1. Shows how many files are in Temp
             and their total size. Deletes nothing.
   ----------------------------------------------------- */
void scanJunk() {
    printf("\nScanning Temp folder...\n");

    if (!startWalk(0)) {   /* 0 = look only */
        return;
    }

    printf("\nFiles found : %d\nTotal size  : ", fileCount);
    printSize(totalBytes);
    if (incomplete) {
        printf("\n\nWarning: some folders could not be read. The numbers may be too low.\n");
    } else {
        printf("\n\nScan complete.\n");
    }
}

/* -----------------------------------------------------
   Function: cleanJunk
   Purpose : Menu 2. Scans, asks for confirmation, deletes
             the files, shows the real results and saves
             the cleaning time to the log file.
   ----------------------------------------------------- */
void cleanJunk() {
    char answer = 'n';   /* safe default if scanf fails */

    printf("\nPreparing to clean Temp folder...\n");

    /* Step 1: scan first (0 = look only) */
    if (!startWalk(0)) {
        printf("Cleaning stopped.\n");
        return;
    }

    if (fileCount == 0) {
        printf("Nothing to clean.\n");
        return;
    }

    /* Step 2: ask for confirmation */
    printf("Found %d files (", fileCount);
    printSize(totalBytes);
    printf(").\n");
    if (incomplete) {
        printf("Warning: some folders could not be read, so more files may exist.\n");
    }
    printf("Delete them? (y/n): ");
    scanf(" %c", &answer);
    clearInput();

    if (answer != 'y' && answer != 'Y') {
        printf("Cancelled. Nothing was deleted.\n");
        return;
    }

    /* Step 3: check Temp again and delete (1 = look and delete).
       The folder is walked again, so we never use old results. */
    if (!startWalk(1)) {
        printf("Cleaning stopped. Nothing was deleted.\n");
        return;
    }

    /* Step 4: show the real results */
    if (incomplete) {
        printf("\nCleaning finished WITH PROBLEMS. Some folders could not be read,\n"
               "so some files may remain.\n");
    } else {
        printf("\nCleaning complete.\n");
    }
    printf("Files deleted : %d\n", fileCount);
    printf("Files skipped : %d (in use, protected or links)\nSpace freed   : ", skipped);
    printSize(totalBytes);
    printf("\n");

    /* Save the time of this cleaning session (only if something was deleted) */
    if (fileCount == 0) {
        return;
    }
    if (writeLog()) {
        printf("Session saved to the ZeroJunk history log.\n");
    } else {
        printf("Could not save the log file.\n");
    }
}

/* -----------------------------------------------------
   Function: viewLogs
   Purpose : Menu 3. Shows the saved cleaning history.
   ----------------------------------------------------- */
void viewLogs() {
    char logPath[MAX_PATH_TXT];
    FILE *fp = NULL;
    char line[200];   /* one log line is short (about 35 characters) */

    if (getLogPath(logPath, sizeof(logPath))) {
        fp = fopen(logPath, "r");
    }
    if (fp == NULL) {
        printf("\nNo logs found yet. Run 'Clean' first.\n");
        return;
    }

    printf("\n----- Cleaning History -----\n");
    while (fgets(line, sizeof(line), fp) != NULL) {
        printf("%s", line);
    }
    printf("-----------------------------\n");
    fclose(fp);
}

/* -----------------------------------------------------
   Function: askDeleteConfirmation
   Purpose : Used when --clean is started by hand (without
             --yes-delete). The user must type the word DELETE
             exactly. Anything else, or closed input (EOF),
             counts as "no".
             Returns 1 = confirmed, 0 = not confirmed.
   ----------------------------------------------------- */
int askDeleteConfirmation() {
    char line[32];   /* big enough for "DELETE" plus a few extra characters */

    printf("Type DELETE (capital letters) and press Enter to confirm: ");
    fflush(stdout);
    if (fgets(line, sizeof(line), stdin) == NULL) {
        return 0;    /* no input at all -> safe answer is "no" */
    }
    line[strcspn(line, "\r\n")] = '\0';   /* remove the Enter character */
    return strcmp(line, "DELETE") == 0;
}

/* -----------------------------------------------------
   Function: cliMode
   Purpose : Used by the Python GUI. Runs ONE job without the
             menu and prints ONE line the GUI can read:
               RESULT files=<n> bytes=<n> skipped=<n> incomplete=<0|1> log=<0|1>
             Returns 0 = OK, 1 = Temp not safe (nothing touched),
             2 = unknown option, 3 = cleaning cancelled (nothing deleted).
             --clean needs a confirmation: either the user types
             DELETE, or the caller passes --yes-delete as the 2nd
             argument (the GUI does this after its own question).
             The safety checks are the same ones the menu uses,
             because both call startWalk().
   ----------------------------------------------------- */
int cliMode(int argc, char *argv[]) {
    const char *option = argv[1];
    int doDelete;
    int confirmed = 0;   /* 1 = caller passed --yes-delete */
    int logOk = 1;       /* 1 = nothing needed saving, or it was saved */

    if (strcmp(option, "--scan") == 0) {
        doDelete = 0;
    } else if (strcmp(option, "--clean") == 0) {
        doDelete = 1;
    } else {
        printf("Error: Unknown option. Use --scan or --clean.\n");
        return 2;
    }

    /* An optional 2nd argument is only allowed for --clean, and it
       must be exactly --yes-delete. Anything else is refused, so a
       typing mistake can never delete files by accident. */
    if (argc >= 3) {
        if (doDelete && argc == 3 && strcmp(argv[2], "--yes-delete") == 0) {
            confirmed = 1;
        } else {
            printf("Error: Unknown option. Use --scan, --clean or --clean --yes-delete.\n");
            return 2;
        }
    }

    /* --clean started by hand: scan first, show the numbers, and
       ask the user to type DELETE. Nothing is deleted before that. */
    if (doDelete && !confirmed) {
        if (!startWalk(0)) {
            return 1;   /* isTempSafe() already printed the reason */
        }
        if (fileCount == 0) {
            printf("Nothing to clean.\n");
            return 0;
        }
        printf("Found %d files (", fileCount);
        printSize(totalBytes);
        printf(").\n");
        if (incomplete) {
            printf("Warning: some folders could not be read, so more files may exist.\n");
        }
        printf("These files will be deleted permanently (no Recycle Bin).\n");
        if (!askDeleteConfirmation()) {
            printf("Cancelled. Nothing was deleted.\n");
            return 3;
        }
    }

    if (!startWalk(doDelete)) {
        return 1;   /* isTempSafe() already printed the reason */
    }

    if (doDelete && fileCount > 0) {
        logOk = writeLog();
    }

    printf("RESULT files=%d bytes=%llu skipped=%d incomplete=%d log=%d\n",
           fileCount, totalBytes, skipped, incomplete, logOk);
    return 0;
}

/* -----------------------------------------------------
   Function: main
   Purpose : With an option (--scan / --clean) it runs that job
             for the GUI. With no option it shows the menu and
             calls the right function.
   ----------------------------------------------------- */
int main(int argc, char *argv[]) {
    int choice;
    int result;   /* 1 if scanf read a number */

    if (argc >= 2) {
        return cliMode(argc, argv);
    }

    do {
        printf("\n========= ZeroJunk =========\n");
        printf("1. Scan Junk Files\n");
        printf("2. Clean Junk Files\n");
        printf("3. View Cleaning Logs\n");
        printf("4. Exit\n");
        printf("=============================\n");
        printf("Enter your choice: ");

        result = scanf("%d", &choice);

        if (result == EOF) {
            choice = 4;          /* input closed -> 4 = Exit safely */
        } else {
            clearInput();
            if (result != 1) {
                choice = 0;      /* not a number -> 0 = invalid choice */
            }
        }

        switch (choice) {
            case 1: scanJunk();  break;
            case 2: cleanJunk(); break;
            case 3: viewLogs();  break;
            case 4: printf("\nExiting ZeroJunk. Goodbye!\n"); break;
            default: printf("\nInvalid choice. Please enter 1-4.\n");
        }
    } while (choice != 4);

    return 0;
}

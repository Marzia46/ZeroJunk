# ZeroJunk (Windows 10/11 x64)

Small Temp-folder cleaner. Window = Python Tkinter. Scanning, safety checks and
deleting = C program `zerojunk_backend.exe`. Python never deletes anything.

## Layout
```
main.py                      start the app
build.bat                    one-click build -> release\ZeroJunk_Setup.exe
zerojunk\gui.py, bridge.py   Tkinter window / talks to the C backend
backend\zerojunk_simple_v6.c C source
installer\ZeroJunk.iss       Inno Setup script
tests\                       tests (fake Temp folders only)
```

## Build the installer
1. Double-click `install_tools.bat` (once). It installs x64 Python 3.12, Inno Setup 6 and
   MSYS2 with 64-bit gcc. Close the window afterwards.
2. Double-click `build.bat`. It compiles the backend, runs the tests, runs PyInstaller,
   then Inno Setup, and produces `release\ZeroJunk_Setup.exe`.

Windows 11 ARM: use the x64 tools above (the app is x64 and runs under Windows' emulation).
`build.bat` finds Python with `py -3.12` and only accepts an x64 (win-amd64) build with a working
tkinter. ARM64 Python or an ARM64 gcc are rejected.

The installer installs per user to `%LOCALAPPDATA%\Programs\ZeroJunk` (no admin needed;
the admin choice in the dialog installs to Program Files), creates a Desktop shortcut
and a Start Menu entry, and registers an uninstaller (Settings > Apps). Uninstalling also
removes the history folder.

## Run without installing
`gcc -Os -s -static backend\zerojunk_simple_v6.c -o backend\zerojunk_backend.exe`, then `python main.py`.

## Backend by hand
`--scan` counts only. `--clean` asks you to type `DELETE`. `--clean --yes-delete` skips
the question (the GUI uses it after its own confirmation window). No option = text menu.

## Changes in this version
- Blank window: the layout now uses one grid cell with raised pages (no pack/forget),
  scales with Windows display scaling, and any startup/button error is shown in a box and
  saved to `%LOCALAPPDATA%\ZeroJunk\zerojunk_error.txt` instead of failing silently.
- History log moved to `%LOCALAPPDATA%\ZeroJunk\zerojunk_log.txt` (Program Files is not writable).
- The PyInstaller build bundles the backend and `bridge.py` finds it there.
- Safety (unchanged and kept): only the real Temp folder named `Temp`/`Tmp`, links and
  junctions never followed, files only, permanent delete, confirmation before cleaning.

## Known limits
- The backend uses ANSI Windows functions: files with names that cannot be written in the
  system code page are counted in a scan but skipped when cleaning (safe, never wrong-deleted).
- Files in use, read-only or protected are skipped.
